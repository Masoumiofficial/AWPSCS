import { jsx as _jsx } from "react/jsx-runtime";
import { createRoot } from 'react-dom/client';
import Dashboard from './components/Dashboard';
const el = document.getElementById('apex-v2-root');
if (el)
    createRoot(el).render(_jsx(Dashboard, { api: window.ApexOmega?.rest_url || '/wp-json' }));
