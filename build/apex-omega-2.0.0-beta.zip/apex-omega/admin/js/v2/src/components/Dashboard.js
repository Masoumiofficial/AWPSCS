import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
export default function Dashboard({ api }) {
    const [stats, setStats] = useState(null);
    useEffect(() => { fetch(api + '/apex/v2/stats').then(r => r.json()).then(setStats).catch(() => { }); }, [api]);
    return (_jsxs("div", { className: "apex-v2-dashboard", children: [_jsx("h2", { children: "APEX \u03A9 2.0 \u2014 \u062F\u0627\u0634\u0628\u0648\u0631\u062F \u0632\u0646\u062F\u0647" }), _jsx("pre", { children: JSON.stringify(stats, null, 2) || 'در حال بارگذاری...' }), _jsx("div", { id: "apex-v2-chart", style: { height: 280, background: '#f5f3ff', borderRadius: 12, display: 'grid', placeItems: 'center' }, children: "Chart.js \u0627\u06CC\u0646\u062C\u0627 (timeseries)" })] }));
}
