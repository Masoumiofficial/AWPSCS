<?php
namespace ApexOmega\Core;

if (!defined('ABSPATH')) exit;

/**
 * 💬 نگهبان کامنت هوشمند — APEX Ω 1.7.0
 * برای هر پست/آهنگ بر اساس محبوبیت خواننده + بازدید، کامنت واقع‌گرایانه می‌گذارد
 * - نام‌های ایرانی انگلیسی‌نویسی (200+200) با ترکیب تصادفی اسم 1 + فامیل 5
 * - سه فرمت: فقط اسم / فقط فامیل / اسم+فامیل (20/20/60)
 * - AI: کامنت مرتبط به خواننده/عنوان با fallback قالب فارسی per tier
 * - نگهبان: <10K → 2-3 معمولی، پرطرفدار → متناسب با بازدید تا 60 + رشد روزانه
 */
class CommentGuardian {
    const OPTION = 'apex_omega_commentor';
    const META_LAST = '_apex_comment_guardian_last';
    const META_COUNT = '_apex_comment_guarded_count';

    public static function get_settings(): array {
        $defaults = [
            'enabled' => true,
            'threshold' => 10000, // زیر این = تازه (استاندارد حرفه‌ای)
            'min_comments' => 2,   // حداقل برای تازه — طبیعی
            'max_comments' => 4,   // حداکثر برای تازه — از اسپم جلوگیری
            'daily_growth' => 2,   // هر روز برای پرطرفدار 1-2 تا اضافه (طبیعی)
            'max_per_post' => 60,  // سقف کل کامنت هر پست حتی الماس (اعتبارسنجی)
            'batch' => 0,          // 0=همه (حرفه‌ای: مؤثر 75/تیک → 375 روزانه بدون timeout)
            'only_recent_days' => 0, // 0=همه — پست قدیمی 0کامنت هم پوشش
            'cooldown_hours' => 6, // 2.0 hourly: 6h تعادل طبیعی (was 24h) — hourly rhythm
            'high_views_auto' => true, // 2.1.0: کامنت خودکار برای آهنگ‌های پرطرفدار بدون دخالت انسانی
            'high_views_threshold' => 100000, // آستانه پرطرفدار (100k)
            'close_after_batch' => true, // بستن کامنت بعد از پایان کار (جلوگیری از اسپم لینک روی صفحات قدیمی)
            // نام آهنگ در کامنت — پیش‌فرض خاموش: کاربر واقعی اسم آهنگ را در صفحهٔ همان آهنگ نمی‌نویسد
            'mention_title' => false,
        ];
        $saved = get_option(self::OPTION, []);
        if (!is_array($saved)) $saved = [];
        $out = wp_parse_args($saved, $defaults);
        $out['enabled'] = !empty($out['enabled']);
        $out['threshold'] = max(1000, min(50000, (int)$out['threshold']));
        $out['min_comments'] = max(1, min(10, (int)$out['min_comments']));
        $out['max_comments'] = max($out['min_comments'], min(10, (int)$out['max_comments']));
        $out['daily_growth'] = max(1, min(5, (int)$out['daily_growth']));
        $out['max_per_post'] = max(10, min(500, (int)$out['max_per_post'])); // 2.0 hourly: raised from 100→500 (configurable, removes hard cap)
        $out['batch'] = max(0, min(500, (int)$out['batch'])); // 0=همه، الگوی روزانه
        $out['only_recent_days'] = max(0, min(365, (int)$out['only_recent_days']));
        $out['cooldown_hours'] = max(1, min(168, (int)$out['cooldown_hours']));
        $out['close_after_batch'] = !empty($out['close_after_batch']);
        $out['mention_title'] = !empty($out['mention_title']);
        $out['high_views_auto'] = !empty($out['high_views_auto']);
        $out['high_views_threshold'] = max(10000, min(1000000, (int)$out['high_views_threshold']));
        return $out;
    }

    public static function save_settings(array $data): void {
        $cur = self::get_settings();
        $new = [
            'enabled' => isset($data['enabled']) ? !empty($data['enabled']) : $cur['enabled'],
            'threshold' => isset($data['threshold']) ? (int)$data['threshold'] : $cur['threshold'],
            'min_comments' => isset($data['min_comments']) ? (int)$data['min_comments'] : $cur['min_comments'],
            'max_comments' => isset($data['max_comments']) ? (int)$data['max_comments'] : $cur['max_comments'],
            'daily_growth' => isset($data['daily_growth']) ? (int)$data['daily_growth'] : $cur['daily_growth'],
            'max_per_post' => isset($data['max_per_post']) ? (int)$data['max_per_post'] : $cur['max_per_post'],
            'batch' => isset($data['batch']) ? (int)$data['batch'] : $cur['batch'],
            'only_recent_days' => isset($data['only_recent_days']) ? (int)$data['only_recent_days'] : $cur['only_recent_days'],
            'cooldown_hours' => isset($data['cooldown_hours']) ? (int)$data['cooldown_hours'] : $cur['cooldown_hours'],
            'high_views_auto' => isset($data['high_views_auto']) ? !empty($data['high_views_auto']) : $cur['high_views_auto'],
            'high_views_threshold' => isset($data['high_views_threshold']) ? (int)$data['high_views_threshold'] : $cur['high_views_threshold'],
            // null یعنی «از این فرم ارسال نشده» → مقدار قبلی حفظ شود
            'close_after_batch' => isset($data['close_after_batch']) ? !empty($data['close_after_batch']) : $cur['close_after_batch'],
            'mention_title' => isset($data['mention_title']) ? !empty($data['mention_title']) : $cur['mention_title'],
        ];
        update_option(self::OPTION, $new, false);
        Scheduler::ensure_cron();
    }

    public static function is_enabled(): bool {
        return !empty(self::get_settings()['enabled']);
    }

    // محاسبهٔ هدف کامنت — الگوی ریتم هرساعته (2026-10-21): بازدید + وزن + امتیاز همبسته، gradual increase never decrease
    public static function calculate_target(int $views, int $weight, float $avg = 4.0, bool $is_premium = false, int $post_id = 0): int {
        $views = max(0, $views);
        $weight = max(0, min(100, $weight));
        // پایه بر اساس بازدید — fresh 500-10000 → 3-10 (spec), scalable for million (~50)
        if ($views < 10000) {
            $base_min = 3; $base_max = 10; // freshly spec: 3-10 (was 2-3)
        } elseif ($views < 100000) {
            $base_min = 10; $base_max = 20; // was 5-10
        } elseif ($views < 500000) {
            $base_min = 20; $base_max = 40; // was 12-25
        } else {
            $base_min = 35; $base_max = 70; // was 30-60 — million scale
        }
        // ضریب وزن: خواننده ویژه 1.2×، نوپا 0.85× — مو لای درز نره
        if ($weight >= 85) {
            $mult = 1.20;
        } elseif ($weight >= 70) {
            $mult = 1.10;
        } elseif ($weight >= 45) {
            $mult = 1.0;
        } elseif ($weight >= 30) {
            $mult = 0.95;
        } else {
            $mult = 0.85;
        }
        // ضریب امتیاز: ستاره‌دار بیشتر کامنت می‌گیرد (همبستگی بازدید↔امتیاز)
        $rating_mult = 0.85 + ($avg / 5) * 0.30; // avg 5→1.15، avg 3→1.03
        $mult *= $rating_mult;
        // خوانندهٔ شناخته‌شده ولی آهنگ تازه (وزن بالا + بازدید کم) → وسط: نه خیلی کم نه خیلی زیاد
        if ($weight >= 75 && $views < 10000) {
            // آهنگ تازه از سوپراستار — طبیعی‌تر: 3-5 نه 2-3
            $mult = max($mult, 1.05);
        }
        $target = (int) round( (($base_min + $base_max)/2) * $mult + mt_rand(-1,1) );
        $target = max($base_min, min($base_max, $target));
        // سقف نوپا حتی اگر بازدید بالا برود ولی وزن پایین: max 6 — منتخب معاف
        if (!$is_premium && $weight < 30 && $target > 6 && $views < 50000) {
            $target = min($target, 6);
        }
        // منتخب ویژه selected-works — پرفکت، توجه ویژه: 35% بیشتر + حداقل 18 کامنت برای میلیونی
        if ($is_premium) {
            $target = (int) round($target * 1.35);
            // کف پریمیوم برای آثار میلیونی/نزدیک میلیونی
            if ($views >= 500000 && $target < 22) $target = mt_rand(22, 28);
            elseif ($views >= 100000 && $target < 16) $target = mt_rand(16, 22);
            elseif ($views >= 10000 && $target < 10) $target = mt_rand(10, 14);
            $target = max($target, $base_min);
            $target = min($target, $base_max + 25); // سقف بازتر برای منتخب
        }
        // هنرمند ناشناخته: حجم بالا + همه تعریفی طبیعی نیست → سقف پایین‌تر
        if (!$is_premium && $weight < 45 && $views < 40000 && $target > 7) {
            $target = mt_rand(4, 7);
        } elseif (!$is_premium && $weight < 45 && $views < 150000 && $target > 12) {
            $target = mt_rand(8, 12);
        }
        // آهنگ ترند: حجم کامنت وایرال (کف ۴۰ و کمی افزایش) — چون در دستهٔ ترند است
        if ($post_id && function_exists('apex_omega_is_trend_post') && apex_omega_is_trend_post($post_id)) {
            $target = (int) round($target * 1.15);
            if ($is_premium && $target < 45) $target = mt_rand(45, 55);
            elseif (!$is_premium && $target < 40) $target = mt_rand(40, 48);
            $target = min($target, 90);
        }
        // بیوگرافی/خبر: این نوع صفحات ذاتاً کامنت کمتری می‌گیرند و پر از تعریف نیستند
        if ($post_id) {
            $ctype = self::detect_content_type($post_id);
            if ($ctype === 'bio') {
                $target = min($target, 12);
            } elseif ($ctype === 'news') {
                $target = min($target, 14);
            }
        }
        // سقف هر پست + تنوع پایدار بین پست‌ها
        // بدون این، همهٔ آهنگ‌های پرطرفدار دقیقاً به «سقف هر پست» می‌رسند و عدد یکسان می‌گیرند (سوتی)
        $cap = (int) self::get_settings()['max_per_post'];
        if ($cap > 0 && $post_id) {
            if ($target >= $cap) {
                $seed = (int) (crc32($post_id . '|' . $cap . '|' . ($is_premium ? 'p' : 'n')) % 1000);
                $factor = $is_premium ? (0.95 + ($seed / 1000) * 0.05) : (0.90 + ($seed / 1000) * 0.10);
                $target = (int) round($cap * $factor);
                // هرگز کمتر از هدف واقعیِ پست نشود مگر اینکه از سقف رد شده باشد
                $target = max(1, min($cap, $target));
            }
            $target = min($target, $cap);
        }
        return $target;
    }

    // نام ایرانی — 85% فارسی + 15% انگلیسی، با تنوع (امیر، امیررضا، amir، amir78، امیر)
    public static function generate_name(): array {
        // فارسی — از ویکی‌پدیا: فهرست نام‌های ایرانی + رده:نام‌های خانوادگی
        $first_fa = ['امیر','امیررضا','امیرحسین','امیرعلی','علی','رضا','حسین','محمد','محمدرضا','محمدحسین','مهدی','سجاد','سینا','آراد','آرش','آریا','آرمان','آرشام','آرشیا','آرتا','آرتین','آروین','اشکان','بابک','بهرام','بهداد','بهنام','بهزاد','بهروز','بورنا','دانیال','داریوش','احسان','عرفان','اسماعیل','فرهاد','فربد','فرزاد','فرشاد','فواد','حامد','حمید','حسن','حسام','هیراد','هومن','هادی','ایمان','جواد','کامیار','کاوه','کسری','کیوان','کیان','کیارش','کوروش','ماهان','مهیار','مانی','منوچهر','منصور','مسعود','مهران','مهرداد','مهرشاد','مهراد','میلاد','محسن','مجتبی','مرتضی','نیما','نوید','امید','پارسا','پرهام','پیام','پدرام','پژمان','پویا','پوریا','رامین','رسول','سعید','سجاد','صالح','سامان','سروش','سام','سپهر','شهاب','شاهین','شهرام','شایان','شروین','سهیل','طاها','وحید','یاسین','یوسف','یونس','زکریا','سارا','سحر','نگین','یاسمن','یاسمین','یلدا','یگانه','یسنا','زهرا','زینب','فاطمه','مریم','مهسا','میترا','مینا','مونا','نرگس','نسرین','نسترن','ندا','نگار','نیلوفر','پریسا','پارمیدا','پردیس','پگاه','ریحانه','رها','روکسانا','روژان','رزا','صدف','سمیرا','ساناز','ساره','ستاره','شادی','شقایق','شیما','شیرین','تارا','ترانه','تینا','سارینا','سوگل','سوگند','شیدا','غزل','هانیه','هدیه','نازنین','مژگان','حدیث','الهه','آتنا','آیدا','آناهیتا','باران','بهار','درسا','دینا','الناز','فائزه','هستی','کیمیا','لاله','مرجان','ملیکا','نادیا','پانته‌آ','پرنیا','رامسینا','سحر','ستایش','آوا','آرزو','آذین','آسنا','النا','الیکا','ماندانا','مینو','نوشین','پروانه','ژیلا','ژاله','هما','هنگامه','وحیده','ویدا','ناهید','نسترن','نیکی','پریا','پرستو','نگار','آیسان','آیسو','سایان','ساینا','سارینا','سلما','سحر','سحرناز','شادی','شراره','شهناز','شیوا','غزل','فاطیما','کتایون','لادن','لیلا','مهتاب','مهناز','مهسا','نازیلا','نسرین','نسیم','نیوشا','پانته‌آ','پریسا','پریا','پگاه','ترانه','تینا','حدیث','خاطره','درسا','دریا','دینا','رابعه','راضیه','رقیه','ریحانه','زهره','سارا','سحر','سحرناز','سمیه','سودابه','سوسن','سولماز','سیما','سیمین','شاپرک','شبنم','شراره','شکوفه','شیما','صبا','صدف','طاهره','عاطفه','عسل','غزل','فائزه','فرشته','فرناز','فهیمه','فیروزه','کتایون','کوثر','لادن','لیلا','مائده','محدثه','مرجان','مرضیه','مریم','مژگان','ملیحه','منا','مهتاب','مهناز','مهسا','مهشید','مونا','مونس','میترا','مینا','نادیا','نازنین','ناهید','ندا','نرگس','نگار','نگین','نیلوفر','ویدا','هانیه','هستی','هنگامه','یاسمن','یاسمین'];
        $last_fa = ['احمدی','حسینی','کریمی','مرادی','یگانه','موسوی','هاشمی','جعفری','نجفی','رضایی','محمدی','حسین‌زاده','کریم‌زاده','مرادی‌زاده','احمدی‌زاده','هاشمی‌زاده','جعفرزاده','کاظمی','رحیمی','رحمانی','بهرامی','قاسمی','صادقی','صالحی','سلطانی','فراهانی','فاضلی','ابراهیمی','حسنی','حیدری','علیزاده','امیری','امیرزاده','آزادی','عظیمی','باقری','بختیاری','برزگر','بیات','بهشتی','داداشی','دانش','دانشور','داوودی','دهقانی','عبادتی','عبادی','اسکندری','فلاح','فلاحی','فتاحی','غلامی','قنبری','قربانی','حاجی‌زاده','حمیدی','حقی','جمالی','جلالی','جوان','کارگر','کاشانی','کرمانی','خادمی','خلیلی','خندانی','خسروی','کیانی','محمودی','مجیدی','مالکی','منصوری','مرندی','مزاهری','مهرابی','میرزایی','موذنی','معینی','مقدم','محسنی','مختاری','مولوی','منتظری','موحد','نادری','نقوی','نصیری','نظری','نعمت‌اللهی','نیک‌نام','نیکزاد','نوری','امیدوار','پاک‌نژاد','پناهی','پرهیزکار','پارسا','پورمحمدی','قاسمی','قلی‌زاده','رئیسی','رفیعی','رنجبر','رشیدی','رستمی','روحانی','سفری','صحرایی','سجادی','سالاری','سلمانی','سرلک','ستاری','صیاد','شهبازی','شاهی','شاهسواری','شریفی','شجاعی','سلیمانی','طباطبایی','طاهری','تاجیک','توکلی','تهرانی','وحیدی','یزدی','یوسفی','زمانیان','زارع','زارعی','زارع‌پور','زرابی','ذوالفقاری','عباسی','عبدی','اکبری','اکبرزاده','علوی','علی‌پور','انصاری','عرب','عربی','اسدی','عسگری','اشرفی','عطایی','عطاری','عزیزی','بهادری','بابایی','بدیعی','باقرزاده','بختری','بنی','بهروزی','بستان','چاوشی','درویشی','دهقان','اسماعیلی','فرجی','فتحی','فتوحی','گودرزی','حدادی','حقیقی','حکیم','حکیمی','حمزه','هدایت','ایمانی','ایرانی','جباری','جهانگیری','جوادی','کبیری','کمال','کرامپور','خورشیدی','کرد','لطیف','لطفی','مدنی','مهدوی','مخملباف','ملک','میری','مفیدی','مقیمی','نادمی','نعیمی','ناجی','پهلوان','پرویزی','پاشایی','پویا','پورعلی','پوررضا','قادری','قنبری','ربانی','رفیع','رجبی','رمضانی','رسولی','روستا','صابری','صادق‌زاده','سعیدی','صلاح‌شور','سلیمی','صانعی','سرابی','شفیعی','شکوری','شمس','شریعتی','شایان','سهرابی','تاج‌زاده','طالبی','واعظی','یعقوبی','زمانی','زندی','حبیبی','نوری','اکرمی','شیرازی','تهرانی','اصفهانی','تبریزی','مشهدی','شیرزاد','حبیب‌زاده'];
        // انگلیسی — 15% (transliterated)
        $first_en = ['Ali','Reza','Hossein','Mohammad','Amir','Amirhossein','Amirali','Amirreza','Arad','Arash','Aria','Arman','Arsam','Arshia','Arta','Artin','Arvin','Ashkan','Babak','Bahram','Behdad','Behnam','Behzad','Borna','Danial','Dariush','Ehsan','Erfan','Farhad','Farbod','Farzad','Hamed','Hamid','Hassan','Hesam','Hooman','Hadi','Iman','Javad','Kamyar','Kaveh','Kasra','Keivan','Kian','Kiarash','Koroush','Mahdi','Mani','Masoud','Mehran','Mehrdad','Milad','Mohsen','Mojtaba','Morteza','Nima','Navid','Omid','Parsa','Payam','Pedram','Pejman','Pouya','Pouria','Ramin','Saeed','Sajjad','Saleh','Saman','Sepehr','Shahab','Shahin','Shahram','Shayan','Sina','Soheil','Taha','Vahid','Yasin','Yousef','Sara','Sahar','Negin','Yasaman','Yalda','Zahra','Zeinab','Fatemeh','Maryam','Mahsa','Mina','Mona','Narges','Negar','Niloufar','Parisa','Raha','Reyhaneh','Sadaf','Samira','Shadi','Shirin','Tara','Tina'];
        $last_en = ['Ahmadi','Hosseini','Karimi','Moradi','Yeganeh','Mousavi','Hashemi','Jafari','Najafi','Rezai','Mohammadi','Karimzadeh','Kazemi','Rahimi','Bahrami','Ghasemi','Sadeghi','Salehi','Soltani','Ebrahimi','Hassani','Heidari','Alizadeh','Amiri','Azimi','Bagheri','Barzegar','Danesh','Gholami','Ghorbani','Hajizadeh','Hamidi','Jamali','Kargar','Khademi','Khalili','Khosravi','Kiani','Mahmoudi','Maleki','Mansouri','Mirzaei','Moeini','Naderi','Nasiri','Nazari','Nouri','Paknejad','Ranjbar','Rashidi','Rostami','Rouhani','Safari','Soleimani','Tabatabaei','Taheri','Tajik','Tavakoli','Tehrani','Yousefi','Zare','Abbasi','Akbari','Alavi','Ansari','Asadi','Ataei','Azizi','Babaei','Shariati','Shams','Sohrabi','Zamani'];

        $use_fa = mt_rand(1,100) <= 85;
        if ($use_fa) {
            $f = $first_fa[array_rand($first_fa)];
            $l = $last_fa[array_rand($last_fa)];
            // تنوع نام کوچک: گاهی امیررضا، گاهی امیر + فاصله + رضا
            // تنوع پسوند فارسی
            $suffixes_fa = ['', '', '', '']; // همه پسوندهای عزیز/عزیزم/جون/جان/کوچولو حذف شد — نام تمیز ایرانی
            $suffix = $suffixes_fa[array_rand($suffixes_fa)];
            // 2.0 hourly: no numeric suffix for Persian names — as requested (no numeric prefix/suffix before Persian names)
            $num_suffix = ''; // removed 15% numeric logic for Persian
            $r = mt_rand(1,100);
            if ($r <= 20) {
                $author = $f . $suffix . $num_suffix;
            } elseif ($r <= 40) {
                $author = $l . $suffix . $num_suffix;
            } else {
                $author = $f . ' ' . $l . $suffix . $num_suffix;
            }
            // ایمیل از روی transliteration ساده
            $base = strtolower(self::transliterate_fa_to_en($f . ' ' . $l));
            $base = preg_replace('/[^a-z]/','', $base);
            if (strlen($base) < 3) $base = 'user' . mt_rand(100,999);
        } else {
            $f = $first_en[array_rand($first_en)];
            $l = $last_en[array_rand($last_en)];
            // تنوع انگلیسی: amir, Amir, AMIR, amir78, amir_2000
            $variants = ['', '78','2000','123','007','_78','_2000','1369'];
            $num_suffix = $variants[array_rand($variants)];
            $case_r = mt_rand(1,100);
            if ($case_r <= 30) $f = strtolower($f);
            elseif ($case_r <= 60) $f = ucfirst(strtolower($f));
            // else keep as is
            $lvar = $l;
            if (mt_rand(1,100) <= 30) $lvar = strtolower($lvar);
            $r = mt_rand(1,100);
            if ($r <= 20) $author = $f . $num_suffix;
            elseif ($r <= 40) $author = $lvar . $num_suffix;
            else $author = $f . ' ' . $lvar . $num_suffix;
            $base = strtolower(str_replace(' ', '.', $f . ' ' . $l));
            $base = preg_replace('/[^a-z\.]/','', $base);
        }
        $base = preg_replace('/[^a-z\.]/','', $base);
        if (strlen($base) < 3) $base = 'user'.mt_rand(1000,9999);
        $base = trim($base,'.');
        $num = mt_rand(101, 9999);
        $domains = ['gmail.com','yahoo.com','outlook.com','icloud.com'];
        $email = $base . $num . '@' . $domains[array_rand($domains)];
        return ['author'=>trim($author), 'email'=>$email];
    }
    private static function transliterate_fa_to_en(string $fa): string {
        // نگاشت ساده برای ایمیل — کامل نیست ولی کافی
        $map = ['ا'=>'a','ب'=>'b','پ'=>'p','ت'=>'t','ث'=>'s','ج'=>'j','چ'=>'ch','ح'=>'h','خ'=>'kh','د'=>'d','ذ'=>'z','ر'=>'r','ز'=>'z','ژ'=>'zh','س'=>'s','ش'=>'sh','ص'=>'s','ض'=>'z','ط'=>'t','ظ'=>'z','ع'=>'a','غ'=>'gh','ف'=>'f','ق'=>'gh','ک'=>'k','گ'=>'g','ل'=>'l','م'=>'m','ن'=>'n','و'=>'o','ه'=>'h','ی'=>'y','آ'=>'a','ئ'=>'e','ء'=>'','ً'=>'','ٌ'=>'','ٍ'=>'','َ'=>'a','ِ'=>'e','ُ'=>'o','ّ'=>'','ـ'=>'','‌'=>'',' '=>' '];
        $en = strtr($fa, $map);
        // پاکسازی کاراکترهای خاص
        $en = preg_replace('/[^a-zA-Z0-9 ]/','', $en);
        return $en ?: 'user';
    }

    // تمیز کردن عنوان خام (حذف "دانلود آهنگ ..." + اسم خواننده) — از متا کمک بگیر نه کپی عنوان
    // trim امن برای فارسی — trim() بایتی رشتهٔ UTF-8 را خراب می‌کند (باگ قدیمی: حرف اول/آخر می‌پرید)
    private static function trim_sep(string $s, string $extra = ''): string {
        $class = '\s\-–—|:،؛«»""\'\x{200C}\x{200F}\x{200E}' . $extra;
        $r = preg_replace('/^[' . $class . ']+|[' . $class . ']+$/u', '', (string)$s);
        return $r === null ? trim((string)$s) : $r;
    }

    // نام هنرمندان شناخته‌شده (کش‌شده) — فقط برای زمانی که اسم خواننده پاس داده نشده
    private static function known_artist_names(): array {
        static $cache = null;
        if ($cache !== null) return $cache;
        $cache = [];
        if (!function_exists('get_terms') || !class_exists('\ApexOmega\Core\ArtistManager')) return $cache;
        $tax = \ApexOmega\Core\ArtistManager::detect_artist_taxonomy();
        if (!$tax || is_wp_error($tax)) return $cache;
        $terms = get_terms(['taxonomy' => $tax, 'hide_empty' => false, 'number' => 500, 'fields' => 'names']);
        if (is_array($terms) && !is_wp_error($terms)) $cache = $terms;
        return $cache;
    }

    // حذف «آویز»های عنوان: از / با / اثر / کیفیت 320 ... که اسم آهنگ نیستند
    private static function strip_title_noise(string $t): string {
        $t = trim($t);
        // 1) پسوندهای کیفیت/فرمت که در سایت‌های دانلود رایج است
        $t = preg_replace('/\s*(?:با\s*کیفیت|کیفیت|bitrate|kbps|mp3|ام\s*پی\s*سه|۳۲۰|320|128|192|256)(?:\s*[^\p{L}\p{N}]*\s*[\p{N}\p{L}]*)*\s*$/iu', '', $t);
        // 2) حذف پرانتز/گیومه‌های انتهایی
        $t = preg_replace('/\s*[\(\[][^\)\]]*[\)\]]\s*$/u', '', $t);
        // 3) حرف اضافهٔ آویزان در انتها — مهم‌ترین بخش: «دلداده از» → «دلداده»
        // فقط انتها را می‌زنیم؛ «از تو می‌گم» یا «دلم از تو گرفته» باید دست‌نخورده بماند
        $tail = '(?:از|با|به|برای|اثر|و|که|همراه|همراهم|از\s*خواننده|با\s*صدای|به\s*خوانندگی|از\s*گروه|از\s*آلبوم)';
        for ($i = 0; $i < 3; $i++) {
            $before = $t;
            $t = preg_replace('/\s+' . $tail . '\s*$/u', '', $t);
            $t = self::trim_sep($t, "‘’“”،,.;:!?؟");
            if ($t === $before) break;
        }
        return trim($t);
    }

    private static function clean_song_title(string $raw, string $artist): string {
        $t = trim($raw);
        $had_dl = false;
        // حذف پیشوندهای رایج
        $prefixes = ['دانلود آهنگ ','دانلود موزیک ','دانلود آهنگ جدید ','دانلود ','آهنگ جدید ','آهنگ ','موزیک ','Download ','download ','دانلود رایگان '];
        foreach ($prefixes as $pre) {
            if (mb_stripos($t, $pre) === 0) {
                $t = trim(mb_substr($t, mb_strlen($pre)));
                $had_dl = true;
            }
        }
        // حذف براکت/پرانتز از کل عنوان («(کیفیت 320)» و ...)
        $t = preg_replace('/\s*[\(\[][^\)\]]*[\)\]]\s*/u', ' ', $t);
        // —— مهم: «از + نام خواننده» را با خودِ حرف اضافه پاک کن ——
        // عنوان سایت: «دانلود آهنگ دلداده از پازل بند» → «دلداده» (نه «دلداده از»)
        $artist = trim($artist);
        if ($artist !== '' && mb_strlen($artist) > 2 && mb_stripos($artist, 'هنرمند') !== 0) {
            $qa = preg_quote($artist, '/');
            $t = preg_replace('/\s*(?:از\s*خواننده|از\s*گروه|با\s*صدای|به\s*خوانندگی|به\s*همراهی|اثر|از|با)\s*' . $qa . '\s*/u', ' ', $t);
            // حذف سادهٔ نام خواننده (هر جای دیگر عنوان)
            if (mb_stripos($t, $artist) !== false) {
                $t = str_ireplace($artist, ' ', $t);
            }
        } elseif ($had_dl) {
            // اسم خواننده پاس نشده: اگر انتهای عنوان یکی از هنرمندان شناخته‌شده بود، از «از» به بعد را بردار
            $known = self::known_artist_names();
            foreach ($known as $kn) {
                if (mb_strlen($kn) < 3) continue;
                $qk = preg_quote($kn, '/');
                if (preg_match('/^(.+?)\s+(?:از|با\s*صدای|اثر|به\s*خوانندگی)\s*' . $qk . '\s*$/u', $t, $m)) {
                    $t = $m[1];
                    break;
                }
            }
        }
        // حذف جداکننده‌های باقی‌مانده + «از»/«با» آویزان
        $t = self::strip_title_noise($t);
        $t = self::trim_sep($t, "‘’“”");
        // اگر تمیزکاری همه را پاک کرد (مثلاً عنوان فقط «همایون شجریان» بود)، برگشت به خام بدون پیشوند
        if (!$t || mb_strlen($t) < 2) {
            $t = trim(str_ireplace(['دانلود آهنگ','دانلود'], ' ', $raw));
            $t = self::strip_title_noise(self::trim_sep($t));
            if (!$t || mb_strlen($t) < 2) return '';
        }
        return $t;
    }

    /* ============ لایهٔ ارتباط طبیعی با خواننده / آهنگ / تیکهٔ ترانه ============ */
    // آیا نام خواننده واقعی است یا جای‌نگهدار («هنرمند ناشناس»)؟ جای‌نگهدار هرگز در کامنت نمی‌آید
    public static function artist_is_placeholder(string $a): bool {
        $a = trim($a);
        if ($a === '') return true;
        $low = str_replace(['‌', 'ي', 'ك'], ['', 'ی', 'ک'], mb_strtolower($a));
        if (preg_match('/^(?:هنرمند|خواننده|گروه|آهنگ|موزیک|unknown|artist|n\/?a)(?:\s+(?:ناشناس|ناشناخته|نامشخص|unknown))?$/u', $low)) return true;
        if (mb_strpos($low, 'ناشناس') !== false || mb_strpos($low, 'نامشخص') !== false) return true;
        return false;
    }
    // نام کوتاه خواننده برای «... جان»
    private static function artist_first_word(string $a): string {
        if (self::artist_is_placeholder($a)) return '';
        $a = trim(preg_replace('/\s*\([^)]*\)/u', '', $a));
        $w = preg_split('/\s+/u', $a) ?: [];
        return count($w) ? trim($w[0]) : '';
    }
    private static function artist_short(string $a): string {
        if (self::artist_is_placeholder($a)) return '';
        $a = trim(preg_replace('/\s*\([^)]*\)/u', '', $a));
        $w = preg_split('/\s+/u', $a) ?: [];
        if (count($w) > 2) $a = implode(' ', array_slice($w, 0, 2));
        return trim($a);
    }
    // عنوان آهنگ کوتاه و امن برای استفاده داخل کامنت
    private static function title_short(string $t, int $max_words = 4): string {
        $t = trim(preg_replace('/\s+/u', ' ', $t));
        $t = preg_replace('/\s*[\(\[][^\)\]]*[\)\]]\s*/u', ' ', $t);
        $t = self::trim_sep($t);
        $t = self::strip_title_noise($t);
        // حذف کلمات عمومی که اسم اثر نیستند (وگرنه «آلبوم جدید» به‌عنوان نام آهنگ می‌آید)
        $generic = '/^(?:آلبوم|آهنگ|موزیک|موزیک\s*ویدیو|موزیک\s*ویدئو|کلیپ|ویدیو|جدید|جدیدترین|رسمی|اورجینال|نسخه|بیوگرافی|زندگینامه|خبر|اخبار|دانلود)+\s*/u';
        for ($i = 0; $i < 4; $i++) {
            $new = preg_replace($generic, '', $t);
            if (!is_string($new) || $new === $t) break;
            $t = trim($new);
        }
        $t = self::strip_title_noise(self::trim_sep($t));
        if ($t === '' || mb_strlen($t) < 3) return '';
        // اگر فقط حرف اضافه/کلمهٔ عمومی مانده بود، نام آهنگ نده (بهتر از «دلداده از»)
        if (preg_match('/^(?:از|با|به|برای|که|و|در|روی|تا|اثر|آهنگ|موزیک|ترک)$/u', $t)) return '';
        $w = preg_split('/\s+/u', $t) ?: [];
        if (count($w) > $max_words) $t = implode(' ', array_slice($w, 0, $max_words));
        if (mb_strlen($t) > 34) {
            // برش از مرز کلمه (نه وسط کلمه)
            $cut = mb_substr($t, 0, 34);
            $sp = mb_strrpos($cut, ' ');
            if ($sp !== false && $sp > 12) $cut = mb_substr($cut, 0, $sp);
            $t = trim($cut);
        }
        return trim($t);
    }
    // استخراج یک تیکهٔ واقعی از متن ترانه (اگر روی سایت موجود باشد) — بدون حدس زدن
    private static function extract_lyric_hook(int $post_id): string {
        if (!$post_id) return '';
        $keys = ['lyrics','lyric','song_lyrics','apex_lyrics','متن_آهنگ','متن آهنگ','متن','ترانه','_lyrics'];
        $raw = '';
        foreach ($keys as $k) {
            $v = get_post_meta($post_id, $k, true);
            if (is_string($v) && mb_strlen(trim($v)) > 12) { $raw = $v; break; }
        }
        if ($raw === '') {
            $c = (string) get_post_field('post_content', $post_id);
            if (mb_strlen($c) > 200) $raw = $c;
        }
        if (mb_strlen($raw) < 12) return '';
        $clean = wp_strip_all_tags($raw);
        $clean = html_entity_decode($clean, ENT_QUOTES, 'UTF-8');
        $lines = preg_split('/[\r\n\.\!؟\|]+/u', $clean) ?: [];
        $cands = [];
        foreach ($lines as $ln) {
            $ln = self::trim_sep($ln);
            if (mb_strlen($ln) < 12 || mb_strlen($ln) > 46) continue;
            if (preg_match('/https?:|www\.|\.(mp3|zip|jpg|png|rar)|دانلود|کلیک|سایت|پخش|اشتراک|حق نشر/u', $ln)) continue;
            if (preg_match('/آهنگ|موزیک|ترانه|آلبوم|خواننده|کیفیت|بیت\s*ریت|ریمیکس|کاور|پست|مطلب|نویسنده|منبع|جدیدترین|منتشر/u', $ln)) continue;
            if (preg_match('/[A-Za-z]{4,}/u', $ln)) continue;
            $w = preg_split('/\s+/u', $ln) ?: [];
            if (count($w) < 3 || count($w) > 7) continue;
            $cands[] = $ln;
        }
        if (!$cands) return '';
        return $cands[($post_id * 9301 + 49297) % count($cands)];
    }
    // اگر متن ترانه روی سایت نبود: اشارهٔ تماتیک به تیکهٔ ترانه (هیچ نقل‌قول جعلی نمی‌سازیم)
    private static function lyric_theme_lines(): array {
        return [
            'اون تیکه که از دلتنگی میگه دلمو گرفت',
            'جایی که از رفتن میگه بغض کردم',
            'اون قسمتش که از عشق میگه حرف نداره',
            'بیت آخرش خیلی سنگینه',
            'متنش انگار حرف دل خودمه',
            'اون تیکه که میگه تنهام مونده… وای',
            'قسمت آرومش که پچ‌پچ میکنه عالیه',
            'جایی که صداش می‌شکنه دلم می‌ریزه',
            'شعرش از اوناست که باید چند بار گوش بدی تا بفهمی',
            'اون تیکه‌ای که آروم میخونه رو چند بار برگردوندم',
            'متنش انقدر قشنگه که دلم نمیاد رد شم',
            'همون قسمتش که نفس میگیره، عالیه',
            'تیکهٔ آخرش منو برد',
            'جایی که میگه برمیگردم، دلم لرزید',
            'اون پاراگراف که آروم شروع میشه محشره',
        ];
    }

    /* ============ تشخیص نوع محتوا: آهنگ / آلبوم / موزیک‌ویدیو / بیوگرافی / خبر ============ */
    public static function detect_content_type(int $post_id, string $title = ''): string {
        static $cache = [];
        $ck = $post_id . '|' . mb_substr($title, 0, 60);
        if (isset($cache[$ck])) return $cache[$ck];
        $hay = ' ' . mb_strtolower($title) . ' ';
        if ($post_id) {
            $hay .= ' ' . mb_strtolower((string) get_the_title($post_id)) . ' ';
            foreach (['category', 'post_tag'] as $tax) {
                if (!function_exists('get_the_terms')) continue;
                $terms = get_the_terms($post_id, $tax);
                if (is_array($terms)) {
                    foreach ($terms as $tm) {
                        if (!is_object($tm)) continue;
                        $hay .= ' ' . mb_strtolower((string)($tm->name ?? '')) . ' ' . mb_strtolower((string)($tm->slug ?? '')) . ' ';
                    }
                }
            }
            // دستهٔ والد هم مهم است (مثلاً زیرشاخهٔ «بیوگرافی خواننده‌ها»)
            $cats = function_exists('get_the_category') ? get_the_category($post_id) : [];
            if (is_array($cats)) foreach ($cats as $c) {
                if (!is_object($c)) continue;
                if (!empty($c->parent) && function_exists('get_term')) {
                    $par = get_term((int)$c->parent);
                    if (is_object($par) && !is_wp_error($par)) $hay .= ' ' . mb_strtolower((string)($par->name ?? '')) . ' ';
                }
            }
        }
        $hay = preg_replace('/\s+/u', ' ', $hay);

        $type = 'song';
        // بیوگرافی / زندگی‌نامه
        if (preg_match('/بیوگرافی|بیوگرافى|زندگینامه|زندگى‌نامه|زندگی‌نامه|زندگي‌نامه|سیره|biography|\bbio\b|پروفایل|کیست|چند سالشه/u', $hay)) $type = 'bio';
        // آلبوم
        elseif (preg_match('/آلبوم|\balbum\b|\bep\b|ئی‌پی|ای‌پی|میکس‌تیپ|mixtape|آهنگ‌های آلبوم/u', $hay)) $type = 'album';
        // موزیک ویدیو / کلیپ
        elseif (preg_match('/موزیک ?ویدیو|موزیک ?ویدئو|موزیک‌ویدیو|\bvideo\b|\bclip\b|کلیپ|\bmv\b|تیزر|teaser/u', $hay)) $type = 'video';
        // خبر
        elseif (preg_match('/\bخبر\b|اخبار|\bnews\b|اطلاعیه|بیانیه|اعلام شد|رونمایی شد|واکنش|شایعه|گفتگو|مصاحبه|interview|به گزارش|روابط عمومی|برگزار می‌شود|برگزار میشود|بلیط‌فروشی|بلیط فروشی|درگذشت|تسلیت/u', $hay)) $type = 'news';
        // «کنسرت» فقط اگر نشانهٔ موزیک بودن متن نباشد (آهنگ/آلبوم/موزیک‌ویدیو)
        elseif (preg_match('/کنسرت|تور\b|اجرای زنده|جشنواره/u', $hay) && !preg_match('/آهنگ|موزیک|ترانه|آلبوم|کلیپ/u', $hay)) $type = 'news';
        $cache[$ck] = $type;
        return $type;
    }

    // آیا اسم آهنگ اجازه دارد در کامنت بیاید؟ (پیش‌فرض: نه — آدم واقعی در صفحهٔ خود آهنگ اسمش را تکرار نمی‌کند)
    public static function mention_title_enabled(): bool {
        $s = self::get_settings();
        return !empty($s['mention_title']);
    }

    // سطح شناخته‌شدن هنرمند — ناشناخته نباید سیل تعریف و تمجید بگیرد
    public static function recognition_level(int $weight, int $views): string {
        if ($weight >= 70 || $views >= 300000) return 'high';
        if ($weight >= 45 || $views >= 60000) return 'mid';
        return 'low';
    }

    /* ============ استخر اختصاصی «آهنگ‌های ترند» — وایرال و نوستالژی، بر اساس خود خواننده و آهنگ ============ */
    private static function trend_pool(int $post_id, string $artist, string $title, string $focus = 'mixed'): array {
        // اگر نام خواننده پاس داده نشد، از خود آهنگ استخراج کن (کامنت باید دقیقاً مربوط به همان خواننده باشد)
        if (mb_strlen(trim($artist)) < 2 && $post_id) {
            $artist = self::get_primary_artist($post_id);
        }
        $a = self::artist_short($artist);
        $f = self::artist_first_word($artist);
        // عنوان تمیز: «دانلود آهنگ ...» و نام خواننده حذف می‌شود تا نام واقعی آهنگ در کامنت بیاید
        $tt = self::title_short(self::clean_song_title($title, $artist));
        $hook = self::extract_lyric_hook($post_id);

        // —— عمومی: وایرال / نوستالژی ——
        $generic = [
            'این آهنگ یه زمانی همه‌جا بود، هنوزم حرف نداره',
            'قدیمیه ولی هیچ‌وقت از مد نمیفته',
            'نسل ما با این آهنگ بزرگ شد',
            'این ترند شد، حقش بود؛ از اول شاهکار بود',
            'چرا تازه همه فهمیدن این آهنگ چقدر خوبه؟',
            'جزو خاطرات یه نسلِ، دست نزنید بهش',
            'این آهنگ مال دوران طلایی موزیک ایرانه',
            'هنوز تو همه پلی‌لیست‌ها هست',
            'چند سال گذشته، هنوز گوش میدم',
            'اینو همه بلدن، از حفظ',
            'وایرال شدنش تعجب نداره، آهنگ موندگاریه',
            'همه تو مهمونی اینو میخونن',
            'این آهنگ ترند شده یعنی مردم سلیقه دارن',
            'یادش بخیر، اون موقع همه با این آهنگ زندگی می‌کردن',
            'این آهنگ کلاسیک شده دیگه',
            'از اون آهنگاست که با یه بار گوش دادن فراموش نمی‌شه',
            'ترند شدنش دوباره زنده‌ش کرد، خوشحالم',
            'چقدر خاطره با این آهنگ دارم',
        ];

        // —— با نام دقیق آهنگ (فقط اگر در تنظیمات روشن شده باشد) ——
        $by_title = [];
        if (mb_strlen($tt) >= 3 && self::mention_title_enabled()) {
            $by_title = [
                '«' . $tt . '» رو همه از حفظن',
                '«' . $tt . '» هنوزم تو گوشیه همه‌ست',
                'اینکه «' . $tt . '» ترند شده نشون می‌ده مردم سلیقه دارن',
                '«' . $tt . '» رو سال‌هاست گوش میدم هنوز سیر نشدم',
                'کاش بازم مثل «' . $tt . '» ساخته بشه',
                '«' . $tt . '» یه بار تو گوشت بیاد دیگه از سرت بیرون نمی‌ره',
                'کسی هست که «' . $tt . '» رو یادش نباشه؟',
                '«' . $tt . '» جزو بهترین کارای این چند ساله',
                'هنوز «' . $tt . '» رو تو ماشین گوش میدم',
                'تصادفی نیست که «' . $tt . '» ترند شده',
            ];
        }

        // —— با نام خواننده ——
        $by_artist = [];
        if (mb_strlen($a) >= 3) {
            $by_artist = [
                'بهترین کار ' . $a . ' همینه به نظرم',
                $a . ' با این آهنگ یه نسل رو عاشق خودش کرد',
                'صدای ' . $a . ' تو این آهنگ معرکه‌ست',
                'این از اون کارای موندگار ' . $a . ' هست',
                'هنوزم که ' . $a . ' اینو میخونه سالن منفجر می‌شه',
                $a . ' هیچ‌وقت از مد نمیفته',
            ];
            if (mb_strlen($f) >= 2) {
                $by_artist[] = $f . ' جان این آهنگت هیچ‌وقت قدیمی نمی‌شه';
                $by_artist[] = $f . ' جان با این آهنگ نسل ما رو ساختی';
            }
        }

        // —— با تیکهٔ ترانه ——
        $by_lyric = [];
        if ($hook !== '') {
            $by_lyric = [
                'اون تیکه که میگه «' . $hook . '» هنوز مو به تنم سیخ می‌کنه',
                '«' . $hook . '» رو نسل ما از حفظه',
                'همون «' . $hook . '» رو تو خیابون همه می‌خوندن',
                'جایی که می‌گه «' . $hook . '» هنوز دلم می‌لرزه',
            ];
        } else {
            $by_lyric = [
                'اون تیکه که از دلتنگی می‌گه هنوز دلمو می‌گیره',
                'قسمت آرومش رو چند بار برگردوندم',
                'متنش انگار حرف دل خودمه',
            ];
        }

        if ($focus === 'title' && $by_title) return array_values(array_unique($by_title));
        if ($focus === 'artist' && $by_artist) return array_values(array_unique($by_artist));
        if ($focus === 'lyric' && $by_lyric) return array_values(array_unique($by_lyric));
        if ($focus === 'generic') return array_values(array_unique($generic));

        return array_values(array_unique(array_merge($generic, $by_title, $by_artist, $by_lyric)));
    }
    // متن پایه بر اساس نوع محتوا (بیوگرافی/خبر هیچ‌وقت کامنت آهنگ نمی‌گیرد)
    private static function typed_pool(string $ctype, string $recog, bool $is_premium = false, bool $is_new_post = false, int $post_id = 0, string $artist = ''): array {
        // بیوگرافی: بدون ادعای «اشتباه نوشتید» و «منبعش ویکی‌پدیاست» — عمومی ولی محترمانه
        $bio = [
            'ممنون از بیوگرافی کاملش', 'خیلی چیزا یاد گرفتم مرسی', 'بخش کودکی‌اش رو دو بار خوندم',
            'کاش درباره شروع کارش بیشتر توضیح می‌دادید', 'واقعا زندگی پرفراز و نشیبی داشته',
            'نمی‌دونستم اینقدر سابقه داره', 'خوندنش خالی از لطف نبود', 'بخش مهاجرتش رو کاملتر بنویسید',
            'چقدر سختی کشیده تا اینجا رسیده', 'ممنون، ولی عکس‌ها کم بود', 'کاش آلبوم‌هاش رو هم لیست می‌کردید',
            'به‌روزرسانی لازم داره، اطلاعات قدیمیه', 'بخش سبک کاریش خیلی کوتاه بود',
            'درباره همکاری‌هاش هم می‌نوشتید خوب بود', 'لایک برای زحمتی که کشیدید', 'چه مسیری طی کرده واقعا',
            'این‌قدر که نوشتید کمه، حقش بیشتره', 'بخش جوایزش رو هم اضافه کنید', 'زندگینامه خوبی بود، ممنون',
        ];
        // خبر: بدون «منبع کجاست؟» و «امیدوارم شایعه باشه» — این‌ها به هر خبری می‌چسبیدند و بی‌ربط بودند
        $news = [
            'خبر رو کامل خوندم، ممنون', 'ممنون از اطلاع‌رسانی سریع', 'خبر داغ بود دمتون گرم',
            'کاش ادامه‌ش رو هم می‌نوشتید', 'منتظر خبرهای بعدی‌ش هستیم', 'خبر خوبی بود',
            'این یکی رو دنبال می‌کردم، ممنون', 'خبرش رو جای دیگه هم دیدم', 'کاش عکس بیشتری می‌گذاشتید',
            'تیتر خوبی زدید، متن هم کامل بود', 'دستتون درد نکنه بابت پوشش خبر',
        ];
        $album = [
            'آلبوم کامل رو گوش دادم، ارزشش رو داره', 'ترک ۴ حرف نداره', 'کدوم ترکش رو بیشتر دوست دارید؟',
            'کاش روی استریم هم می‌اومد', 'چند تا ترک داره؟', 'ترتیب ترک‌ها خیلی خوب چیده شده',
            'همه ترکاش رو دوست داشتم', 'کاور آلبوم خیلی خوبه', 'انتظار بیشتری داشتم ازش',
            'دوتا ترکش ضعیف‌تر بود بقیه عالی', 'کاش نسخه فیزیکیش هم بیاد', 'ترک آخرش بهترین بود',
            'میکس آلبوم یکدسته، کیفیت خوبه', 'قیمت نسخه اورجینالش چند؟', 'بهترین آلبوم امساله به نظرم',
            'هنوز کامل گوش ندادم، ولی شروعش خوب بود', 'ترک ۷ رو چند بار برگردوندم',
        ];
        $video = [
            'کلیپش قشنگ شده', 'کارگردانش کیه؟', 'لوکیشنش کجاست؟ خیلی قشنگه', 'کیفیت تصویرش خوبه',
            'تدوینش حرف نداره', 'کلیپ از خود آهنگ بهتر شده', 'بازیگر کلیپش کیه؟', 'کاش کیفیت 1080 هم می‌ذاشتید',
            'این صحنه آخرش عالی بود', 'آهنگ خوبه ولی کلیپش معمولیه', 'کلیپش خیلی ساده‌ست، انتظار بیشتری داشتم',
            'رنگ‌بندی کلیپ خیلی خوبه', 'کلیپ بدون آهنگ هم قشنگه', 'چند روزه منتظر کلیپش بودم',
            'استوری‌بوردش خوب طراحی شده', 'نورپردازی صحنه دوم عالیه',
        ];
        $neutral_low = [
            'اولین باره اسمشو می‌شنوم، بد نبود', 'جدیده؟ صداش بد نیست', 'کیفیت کارش متوسط بود',
            'برای شروع بد نیست ولی جا داره', 'فکر می‌کردم بهتر باشه', 'ازش چیزی نمی‌دونستم، یه گوش می‌دم',
            'کسی ازش خبری داره؟', 'یکم آماتور بود ولی استعداد داره', 'صداش خاص نیست ولی بدک نبود',
            'با یه بار گوش دادن نظر نمی‌دم', 'میکسش ضعیفه ولی صدا خوبه', 'کاش یه کار بهتر ازش می‌شنیدم',
            'هنوز به پای کارای معروفش نمی‌رسه', 'اسمش رو نشنیده بودم، الان شناختم', 'قابل قبوله برای شروع',
            'خیلی تعریفش رو شنیدم ولی انتظارم بیشتر بود', 'باید بیشتر ازش بشنوم تا نظر بدم',
        ];
        if ($ctype === 'bio' || $ctype === 'news') {
            $facts = $post_id ? self::content_facts($post_id) : [];
            $fact_lines = [];
            if ($facts && !empty($facts['raw_len'])) {
                $fact_lines = ($ctype === 'news') ? self::news_fact_lines($facts) : self::bio_fact_lines($facts, $artist);
            }
            if (!$fact_lines) {
                // متن پست خوانده نشد یا فکتی نبود → همان استخر عمومی (بدون ادعای بی‌ربط)
                return ($ctype === 'bio') ? $bio : $news;
            }
            // ~۹۰٪ خطوط مبتنی بر خود متن + چند خط عمومی (طبیعی بماند)
            $generic = ($ctype === 'bio') ? $bio : $news;
            // تکرار عمدی برای وزن‌دهی (array_unique وزن را صفر می‌کرد)
            return array_merge($fact_lines, $fact_lines, $fact_lines, $fact_lines, $fact_lines, $fact_lines, array_slice($generic, 0, 1));
        }
        if ($ctype === 'album' || $ctype === 'video') {
            $base = ($ctype === 'album') ? $album : $video;
            if ($recog === 'low') {
                $base = array_merge($base, array_slice($neutral_low, 0, 8), $ctype === 'album' ? ['کسی این آلبوم رو معرفی کرده؟', 'اسمش برام ناشناسه، ارزش گوش دادن داره؟'] : []);
            }
            if ($post_id) {
                $facts = self::content_facts($post_id);
                if (!empty($facts['raw_len'])) {
                    $fl = self::album_fact_lines($facts);
                    if ($fl) {
                        return array_merge($fl, $fl, $fl, $fl, $fl, $fl, array_slice($base, 0, 8));
                    }
                }
            }
            return $base;
        }
        return $neutral_low;
    }

    /* ============ خواندن متن خبر/بیوگرافی و ساختن کامنت دربارهٔ همان متن ============ */

    // متن واقعی پست بدون HTML/شورت‌کد و بدون خطوط تبلیغاتی سایت
    public static function post_body_text(int $post_id, int $limit = 4000): string {
        static $cache = [];
        if (isset($cache[$post_id])) return $cache[$post_id];
        $raw = '';
        if ($post_id) {
            $raw = (string) get_post_field('post_content', $post_id);
            if (mb_strlen(trim($raw)) < 60) {
                $ex = (string) get_post_field('post_excerpt', $post_id);
                $raw = trim($raw . "\n" . $ex);
            }
        }
        $txt = strip_shortcodes((string) $raw);
        $txt = preg_replace('/<script[\s\S]*?<\/script>/iu', ' ', $txt);
        $txt = preg_replace('/<style[\s\S]*?<\/style>/iu', ' ', $txt);
        $txt = wp_strip_all_tags($txt);
        $txt = html_entity_decode($txt, ENT_QUOTES, 'UTF-8');
        $txt = str_replace(["\u{200F}", "\u{200E}", "\u{FEFF}"], ' ', $txt);
        $txt = preg_replace('/[ \t]+/u', ' ', $txt);
        // خطوط تبلیغ/تکرارشوندهٔ قالب را حذف کن
        $lines = preg_split('/\r\n|\r|\n/u', $txt) ?: [];
        $keep = [];
        foreach ($lines as $ln) {
            $ln = trim($ln);
            if ($ln === '') continue;
            if (preg_match('/^(?:دانلود|پخش آنلاین|لینک|به اشتراک|نظر شما|دیدگاه|مطالب مرتبط|خبرهای مرتبط|تبلیغات|کلیک کنید|منبع:|نویسنده:|برچسب|دسته)/u', $ln)) continue;
            if (preg_match('/https?:\/\/|www\./iu', $ln)) continue;
            $keep[] = $ln;
        }
        $txt = trim(implode(' ', $keep));
        if (mb_strlen($txt) > $limit) $txt = mb_substr($txt, 0, $limit);
        $cache[$post_id] = $txt;
        return $txt;
    }

    // استخراج «فکت»های قابل استفاده در کامنت — با توجه به جملهٔ پیرامون (تولد ≠ شروع کار)
    public static function content_facts(int $post_id): array {
        static $cache = [];
        if (isset($cache[$post_id])) return $cache[$post_id];
        $txt = self::post_body_text($post_id, 4000);
        $facts = [
            'city' => '', 'city_event' => '', 'city_origin' => '',
            'year' => '', 'years' => [], 'birth_year' => '', 'start_year' => '',
            'quoted' => [], 'topic' => '', 'style' => '', 'tracks' => '',
            'source' => false, 'raw_len' => mb_strlen($txt),
        ];
        if ($txt === '') { $cache[$post_id] = $facts; return $facts; }

        $latin = strtr($txt, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']);
        $fa = function (string $s): string { return strtr($s, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']); };

        // ——— سال‌ها با تشخیص نقش: تولد یا شروع فعالیت ———
        $birth_re = '/تولد|متولد|به دنیا آمد|زاده|دنیا آمد/u';
        $start_re = '/شروع|آغاز|فعالیت|کار خود|پا گرفت|تشکیل/u';
        if (preg_match_all('/(?<!\d)(1[34]\d{2}|20[0-4]\d)(?!\d)/u', $latin, $m, PREG_OFFSET_CAPTURE)) {
            foreach ($m[1] as $hit) {
                $val = (int)$hit[0];
                if (!(($val >= 1300 && $val <= 1420) || ($val >= 2015 && $val <= 2030))) continue;
                $disp = $fa((string)$val);
                if (!in_array($disp, $facts['years'], true)) $facts['years'][] = $disp;
                // PREG_OFFSET_CAPTURE آفست بایتی می‌دهد → با substr (بایتی) بخوان تا پنجرهٔ جمله درست باشد
                $off = (int) $hit[1];
                $ctx_before = substr($latin, max(0, $off - 90), min(90, $off));
                $ctx_after  = substr($latin, $off + strlen($hit[0]), 90);
                if ($facts['birth_year'] === '' && preg_match($birth_re, $ctx_before . ' ' . $ctx_after)) {
                    $facts['birth_year'] = $disp;
                } elseif ($facts['start_year'] === '' && preg_match($start_re, $ctx_before . ' ' . $ctx_after)) {
                    $facts['start_year'] = $disp;
                }
            }
            // اگر هیچ‌کدام نقش مشخصی نداشت، اولین سال
            if ($facts['birth_year'] === '' && $facts['start_year'] === '' && $facts['years']) {
                $facts['start_year'] = $facts['years'][0];
            }
        }
        $facts['year'] = $facts['birth_year'] !== '' ? $facts['birth_year'] : $facts['start_year'];

        // ——— شهر با نقش: محل رویداد یا زادگاه/شروع ———
        $places = ['تهران','اصفهان','شیراز','مشهد','تبریز','رشت','کرج','اهواز','کیش','قشم','بندرعباس','یزد','کرمان','همدان','ارومیه','سنندج','زنجان','ساری','بوشهر','دبی','استانبول','آنتالیا','ارمنستان','گرجستان','لس‌آنجلس','تورنتو','ونکوور','لندن','پاریس','برلین','استکهلم','آلمان','کانادا','آمریکا','استرالیا','هلند','سوئد'];
        $event_re = '/کنسرت|اجرا|برگزار|رونمایی|جشنواره|بلیط|بلیت|رویداد/u';
        $origin_re = '/متولد|تولد|زاده|اصالت|شروع|آغاز|به دنیا/u';
        foreach ($places as $pl) {
            $pos = mb_stripos($txt, $pl);
            if ($pos === false) continue;
            $ctx = mb_substr($txt, max(0, $pos - 45), 45 + mb_strlen($pl) + 45, 'UTF-8');
            if (preg_match($event_re, $ctx) && $facts['city_event'] === '') $facts['city_event'] = $pl;
            if (preg_match($origin_re, $ctx) && $facts['city_origin'] === '') $facts['city_origin'] = $pl;
            if ($facts['city'] === '') $facts['city'] = $pl;
            if ($facts['city_event'] !== '' && $facts['city_origin'] !== '') break;
        }

        // ——— نام‌های داخل گیومه ———
        if (preg_match_all('/«([^»]{3,32})»/u', $txt, $m)) {
            foreach ($m[1] as $q) {
                $q = self::trim_sep($q);
                if (mb_strlen($q) < 3) continue;
                if (preg_match('/^(?:دانلود|آهنگ|آلبوم|جدید|متن|عکس)/u', $q)) continue;
                if (!in_array($q, $facts['quoted'], true)) $facts['quoted'][] = $q;
                if (count($facts['quoted']) >= 3) break;
            }
        }

        // ——— تعداد ترک ———
        if (preg_match('/(\d{1,2})\s*(?:ترک|قطعه|آهنگ)/u', $latin, $m)) {
            $facts['tracks'] = $fa($m[1]);
        }

        // ——— موضوع ———
        $topics = [
            'کنسرت' => '/کنسرت|تور\b|اجرای زنده|روی صحنه|بلیط‌فروشی|بلیط فروشی/u',
            'آلبوم' => '/آلبوم|ئی‌پی|ای‌پی|ترک جدید/u',
            'تک‌آهنگ' => '/تک‌آهنگ|ترانهٔ جدید|ترانه جدید|قطعهٔ جدید|قطعه جدید|سینگل/u',
            'همکاری' => '/همکاری|دو صدایی|دوئت|\bفت\b|feat/iu',
            'مصاحبه' => '/مصاحبه|گفتگو|گفت‌وگو|اعلام کرد/u',
            'جشنواره' => '/جشنواره|فستیوال|جایزه|برنده|نامزد/u',
            'بازگشت' => '/بازگشت|برمی‌گردد|برمیگردد|کنسرت بعد از|دوباره روی صحنه/u',
            'ویدیو' => '/موزیک ?ویدیو|موزیک ?ویدئو|کلیپ|تیزر/u',
            'ازدواج' => '/ازدواج|نامزدی/u',
            'مهاجرت' => '/مهاجرت|زندگی در خارج/u',
            'درگذشت' => '/درگذشت|فوت|تسلیت|خاکسپاری/u',
            'بیماری' => '/بیمار|درمان|عمل جراحی|بستری/u',
            'انتشار' => '/منتشر|عرضه|رونمایی شد|منتشر شد|منتشر می‌شود/u',
        ];
        foreach ($topics as $name => $re) {
            if (preg_match($re, $txt)) { $facts['topic'] = $name; break; }
        }

        // ——— سبک ———
        $styles = ['پاپ','سنتی','رپ','هیپ‌هاپ','هیپ هاپ','راک','کلاسیک','تلفیقی','فولک','محلی','الکترونیک','بی‌کلام','آذری','کردی','مازندرانی','لری','بندری'];
        foreach ($styles as $st) {
            if (mb_stripos($txt, $st) !== false) { $facts['style'] = $st; break; }
        }

        // ——— منبع ذکر شده؟ ———
        $facts['source'] = (bool) preg_match('/منبع|به گزارش|به نقل از|اعلام کرد|روابط عمومی|در گفت‌وگو با|در گفتگو با|پایگاه خبری|ایسنا|ایلنا|مهر|تسنیم|ایرنا|بی‌بی‌سی|bbc/iu', $txt);

        $cache[$post_id] = $facts;
        return $facts;
    }

    // کامنت‌هایی که واقعاً به همان خبر اشاره می‌کنند
    private static function news_fact_lines(array $f): array {
        $lines = [];
        $city  = (string)(($f['city_event'] ?? '') !== '' ? $f['city_event'] : ($f['city'] ?? ''));
        $year  = (string)($f['year'] ?? '');
        $topic = (string)($f['topic'] ?? '');
        $q     = $f['quoted'][0] ?? '';
        $q2    = $f['quoted'][1] ?? '';

        if ($city !== '') {
            if ($topic === 'کنسرت') {
                $lines[] = 'کنسرت ' . $city . ' رو حتماً میام';
                $lines[] = 'بلیط کنسرت ' . $city . ' از کِی میاد؟';
                $lines[] = 'کنسرت ' . $city . ' رو خوب زمان‌بندی کردید';
                $lines[] = 'کاش تاریخ دقیق کنسرت ' . $city . ' رو هم می‌نوشتید';
                $lines[] = 'برای کنسرت ' . $city . ' باید از کجا بلیط بگیریم؟';
                $lines[] = 'کنسرت ' . $city . ' رو از دست نمی‌دم';
                $lines[] = 'این کنسرت تو ' . $city . ' خیلی وقته منتظرش بودم';
                $lines[] = 'امیدوارم برای کنسرت ' . $city . ' بلیط به همه برسه';
                $lines[] = 'ساعت شروع کنسرت ' . $city . ' رو هم می‌نوشتید';
                $lines[] = 'کنسرت ' . $city . ' با این خبر حال همه رو خوب کرد';
            } else {
                $lines[] = 'خبرش رو خوندم، ' . $city . ' رو که گفتید همه‌چی روشن شد';
                $lines[] = 'پس ' . $city . ' بوده، فکر می‌کردم جای دیگه‌ست';
                $lines[] = 'این اتفاق تو ' . $city . ' خیلی به‌جا بود';
                $lines[] = 'برای ' . $city . ' خبر مهمی بود';
                $lines[] = 'کاش جزئیات بیشتری از ' . $city . ' می‌نوشتید';
            }
        }
        if ($q !== '') {
            $lines[] = 'یعنی «' . $q . '» بالاخره اومد؟';
            $lines[] = 'دربارهٔ «' . $q . '» بیشتر توضیح می‌دید؟';
            $lines[] = '«' . $q . '» رو که نوشتید، جدی؟';
            $lines[] = 'پس «' . $q . '» همونیه که منتظرش بودیم';
            if ($q2 !== '') $lines[] = 'بین «' . $q . '» و «' . $q2 . '» کدوم مهم‌تره؟';
        }
        if ($year !== '') {
            $lines[] = 'یعنی ' . $year . ' منتشر می‌شه؟';
            $lines[] = $year . ' رو که نوشتید، تاریخ قطعیه؟';
        }
        if ($topic === 'کنسرت' && $city === '') {
            $lines[] = 'کنسرت رو بالاخره اعلام کردید، بلیط‌فروشی کِی شروع می‌شه؟';
            $lines[] = 'برای کنسرت باید از کجا بلیط بگیریم؟';
            $lines[] = 'این کنسرت رو از دست نمی‌دم';
        } elseif ($topic === 'آلبوم') {
            $lines[] = 'آلبوم کامل کی میاد؟';
            $lines[] = 'چند تا ترک داره آلبوم جدیدش؟';
            $lines[] = 'خبر آلبوم جدیدش رو دنبال می‌کردم';
        } elseif ($topic === 'همکاری') {
            $lines[] = 'همکاریش با این خواننده جالب بود';
            $lines[] = 'این همکاری رو انتظار نداشتم، خوب شد';
        } elseif ($topic === 'مصاحبه') {
            $lines[] = 'مصاحبه رو کامل بخونید، حرفاش مهم بود';
            $lines[] = 'توی مصاحبه چیزهای تازه‌ای گفت';
        } elseif ($topic === 'جشنواره') {
            $lines[] = 'جایزه‌اش حقش بود';
            $lines[] = 'انتظار داشتم بیشتر از این بگیره';
        } elseif ($topic === 'بازگشت') {
            $lines[] = 'بعد از این همه وقت برگشتنش خبر خوبیه';
            $lines[] = 'بالاخره برگشت، منتظرش بودیم';
        } elseif ($topic === 'ویدیو') {
            $lines[] = 'کلیپش کی منتشر می‌شه؟';
            $lines[] = 'برای کلیپ جدیدش منتظرم';
        } elseif ($topic === 'ازدواج') {
            $lines[] = 'خبر ازدواجش رو شنیدم، تبریک';
            $lines[] = 'کاش تاریخش رو هم می‌نوشتید';
        } elseif ($topic === 'مهاجرت') {
            $lines[] = 'مهاجرتش رو نمی‌دونستم';
            $lines[] = 'حیف شد که رفت، ولی موفق باشه';
        } elseif ($topic === 'درگذشت') {
            $lines[] = 'تسلیت به خانواده‌اش، خیلی غم‌انگیز بود';
            $lines[] = 'باورم نمی‌شه، روحش شاد';
        } elseif ($topic === 'بیماری') {
            $lines[] = 'امیدوارم زودتر خوب بشه';
            $lines[] = 'دعا می‌کنیم سلامتش رو به دست بیاره';
        } elseif ($topic === 'انتشار') {
            $lines[] = 'بالاخره منتشر شد، منتظرش بودیم';
            $lines[] = 'خبر انتشارش رو دنبال می‌کردم';
        }
        return array_values(array_unique($lines));
    }

    // کامنت‌هایی که به متن همان بیوگرافی اشاره می‌کنند
    private static function bio_fact_lines(array $f, string $artist = ''): array {
        $lines = [];
        $city = (string)(($f['city_origin'] ?? '') !== '' ? $f['city_origin'] : ($f['city'] ?? ''));
        $birth = (string)($f['birth_year'] ?? '');
        $start = (string)($f['start_year'] ?? '');
        $q    = $f['quoted'][0] ?? '';

        if ($birth !== '') {
            $lines[] = 'تولدش ' . $birth . ' بوده، درست نوشتید؟';
            $latin = (int) strtr($birth, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'۸','۹'=>'9']);
            if ($latin >= 1300 && $latin <= 1420) {
                $jalali_now = (int) gmdate('Y') - 621;
                $age = (int) ($jalali_now - $latin);
                if ($age > 15 && $age < 95) $lines[] = 'یعنی الان ' . strtr((string)$age, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']) . ' سالشه؟';
            }
        }
        if ($start !== '') {
            $lines[] = 'از ' . $start . ' شروع کرده، سابقه‌اش کم نیست';
            $lines[] = 'یعنی از ' . $start . ' تو کار موزیکه';
            $lines[] = 'سال ' . $start . ' رو درست نوشتید؟ فکر می‌کردم دیرتر شروع کرده';
        }
        if ($city !== '') {
            $lines[] = 'اینکه از ' . $city . ' شروع کرده رو نمی‌دونستم';
            $lines[] = 'بخش ' . $city . ' و شروع کارش رو دو بار خوندم';
            $lines[] = $city . ' بودنش رو تو بیوگرافی ندیده بودم';
        }
        if ($q !== '') {
            $lines[] = 'پس با «' . $q . '» کارش رو شروع کرده';
            $lines[] = '«' . $q . '» همون اولش بود؟ یادم نبود';
            $lines[] = 'بخش «' . $q . '» رو کامل‌تر می‌نوشتید';
        }
        $style = (string)($f['style'] ?? '');
        if ($style !== '') {
            $lines[] = 'سبک ' . $style . ' رو خوب توضیح دادید';
            $lines[] = 'اینکه تو ' . $style . ' کار می‌کنه رو نمی‌دونستم';
            $lines[] = 'بخش ' . $style . ' کارش رو بیشتر باز می‌کردید';
        }
        return array_values(array_unique($lines));
    }

    // کامنت‌هایی که به خود آلبوم/ویدیوی همان پست اشاره می‌کنند (نام، تعداد ترک، شهر رونمایی)
    private static function album_fact_lines(array $f): array {
        $lines = [];
        $q = $f['quoted'][0] ?? '';
        $city = (string)(($f['city_event'] ?? '') !== '' ? $f['city_event'] : '');
        $tracks = (string)($f['tracks'] ?? '');
        if ($q !== '') {
            $lines[] = '«' . $q . '» رو کامل گوش دادم، ارزشش رو داره';
            $lines[] = 'یعنی اسم آلبوم «' . $q . '»ه؟ اسم خوبی انتخاب کرده';
            $lines[] = '«' . $q . '» رو از کجا شروع کنم بهتره؟';
        }
        if ($tracks !== '') {
            $lines[] = $tracks . ' ترک داره؟ پس باید کامل گوش بدم';
            $lines[] = $tracks . ' تا ترک برای یه آلبوم کم نیست';
        }
        if ($city !== '') {
            $lines[] = 'رونمایی تو ' . $city . ' کی برگزار می‌شه؟';
            $lines[] = $city . ' بود؟ کاش بیشتر توضیح می‌دادید';
        }
        return array_values(array_unique($lines));
    }

    // ساخت جملهٔ «تعریف از خواننده» یا «اشاره به آهنگ» یا «تیکهٔ ترانه»
    private static function relevance_line(int $post_id, string $artist, string $title, int $weight): array {
        static $used = [];
        $u = array_merge(['artist'=>0,'title'=>0,'lyric'=>0], is_array($used[$post_id] ?? null) ? $used[$post_id] : []);
        $used[$post_id] = $u;
        $cap_artist = 3; $cap_title = 2; $cap_lyric = 3;
        $allow_title = self::mention_title_enabled();
        $pool = [];
        if ($u['artist'] < $cap_artist) $pool = array_merge($pool, array_fill(0, 45, 'artist'));
        if ($allow_title && $u['title'] < $cap_title) $pool = array_merge($pool, array_fill(0, 25, 'title'));
        if ($u['lyric']  < $cap_lyric)  $pool = array_merge($pool, array_fill(0, 30, 'lyric'));
        if (!$pool) return ['type'=>'','text'=>''];
        $type = $pool[array_rand($pool)];
        $choices = [$type];
        $rest = array_values(array_diff($allow_title ? ['artist','title','lyric'] : ['artist','lyric'], [$type]));
        shuffle($rest);
        $choices = array_merge($choices, $rest);
        foreach ($choices as $type) {
            if (!empty($u[$type])) continue;
            if ($type === 'artist') {
                if (self::artist_is_placeholder($artist)) continue;
                $a = self::artist_short($artist);
                $f = self::artist_first_word($artist);
                if (mb_strlen($a) < 3) continue;
                $full = [
                    '{a} همیشه عالی میخونه',
                    'صدای {a} خودش آرامشه',
                    '{a} ترکوند با این کار',
                    '{a} از اون خواننده‌هاست که هر چی بده گوش میدم',
                    'دمت گرم {a}',
                    '{a} صدات به دل میشینه',
                    '{a} چقدر با احساس میخونی',
                    '{a} بهترینه به نظرم',
                    '{a} خسته نباشی، عالی بود',
                    'کارای {a} همیشه یه چیز دیگه‌ست',
                ];
                $first = ['{f} جان دمت گرم','{f} جان محشره','{f} جان چقدر قشنگ خوندی','{f} جان عالی بود','{f} جان ترکوندی'];
                if (mb_strlen($f) >= 2 && mt_rand(1,100) <= 30) {
                    $line = $first[array_rand($first)];
                    $line = str_replace('{f}', $f, $line);
                } else {
                    $line = $full[array_rand($full)];
                    $line = str_replace('{a}', $a, $line);
                }
                $used[$post_id]['artist'] = ($used[$post_id]['artist'] ?? 0) + 1;
                return ['type'=>'artist','text'=>$line];
            }
            if ($type === 'title') {
                $tt = self::title_short($title);
                if (mb_strlen($tt) < 3) continue;
                $tpl = [
                    '«{t}» یکی از قشنگترین کاراتونه',
                    '«{t}» رو چند بار گوش دادم هنوز سیر نشدم',
                    '«{t}» از اون کاراست که خسته نمیشی',
                    '«{t}» رو برای دوستم فرستادم اونم عاشقش شد',
                    'اسم «{t}» هم به دل میشینه',
                    '«{t}» رو تو پلی‌لیستم گذاشتم',
                    '«{t}» یه روز کلاسیک میشه',
                    '«{t}» با این حسش… حرف نداره',
                    'از وقتی «{t}» اومده فقط همینو گوش میدم',
                ];
                $line = str_replace('{t}', $tt, $tpl[array_rand($tpl)]);
                $used[$post_id]['title'] = ($used[$post_id]['title'] ?? 0) + 1;
                return ['type'=>'title','text'=>$line];
            }
            // lyric
            $hook = self::extract_lyric_hook($post_id);
            if ($hook !== '') {
                $tpl = [
                    'اون تیکه که میگه «{h}» دلمو برد',
                    'قسمت «{h}» رو چند بار برگردوندم',
                    '«{h}» این قسمتش خیلی قشنگه',
                    'جایی که میگه «{h}» مو به تنم سیخ شد',
                    'تیکهٔ «{h}» با چه حسی خونده شده',
                    'همون «{h}» ته دلمو خالی کرد',
                ];
                $line = str_replace('{h}', $hook, $tpl[array_rand($tpl)]);
                $used[$post_id]['lyric'] = ($used[$post_id]['lyric'] ?? 0) + 1;
                return ['type'=>'lyric','text'=>$line];
            }
            $themes = self::lyric_theme_lines();
            $line = $themes[array_rand($themes)];
            $used[$post_id]['lyric'] = ($used[$post_id]['lyric'] ?? 0) + 1;
            return ['type'=>'lyric','text'=>$line];
        }
        return ['type'=>'','text'=>''];
    }
    // آیا جملهٔ دوم، تعریف تکراری جملهٔ اول است؟ («محشره واقعا. ... محشره»)
    private static function repeats_praise(string $base, string $extra): bool {
        $praise = ['محشره','محشر','عالیه','عالی','قشنگه','قشنگ','خفنه','خفن','بهترینه','بهترین','حرف نداره','دوسش دارم','دوستش دارم','آرامش','ارامش','زیبا','لذت بردم','شاهکار','معرکه'];
        foreach ($praise as $w) {
            if (mb_stripos($base, $w) !== false && mb_stripos($extra, $w) !== false) return true;
        }
        // تکرار کلمات معنادار (۵ حرف به بالا) هم آزاردهنده است
        $stop = ['خیلی','واقعا','همیشه','اینو','اونو','برام','حالم','دلم','گوش','دادم','میدم','کردم'];
        preg_match_all('/[\p{L}\x{200C}]{5,}/u', $extra, $m);
        foreach (array_unique($m[0] ?? []) as $w) {
            if (in_array($w, $stop, true)) continue;
            if (mb_stripos($base, $w) !== false) return true;
        }
        return false;
    }

    // آیا کامنت لحن منفی/سوالی/محتاط دارد؟ (برای اینکه ایموجی و تعریف به آن نچسبد)
    private static function looks_negative(string $txt): bool {
        return (bool) preg_match('/ضعیف|اذیت|کند|تکراری|قدیمی|گیر|تاخیر|چرا|کاش|متوسط|نبود|نیست|میکسش|شعرش|کیفیتش|انتظار|معمولی|شایعه|باور ?نمی|تایید|منبع|اشتباه|کمتر|به‌روز|چند تا|کیه|کجاست|کدوم|کسی .*داره|نظرتون|می‌دونید|میدونید|رسمی|چک کردم|نامشخص|معلوم نیست/u', $txt);
    }

    // چسباندن طبیعی جملهٔ اضافه به کامنت پایه (بدون خراب کردن لحن قبلی)
    private static function weave(string $base, string $extra, bool $is_lyric = false): string {
        $base = trim($base);
        $extra = trim($extra);
        if ($base === '') return $extra;
        if ($extra === '') return $base;
        if (mb_strlen($base) + mb_strlen($extra) > 165) return $base;
        // ایموجی انتهای کامنت را برمی‌داریم، بعد از چسباندن دوباره آخر می‌گذاریم
        $emoji = '';
        if (preg_match('/(\s*(?:[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}]\x{FE0F}?\s*)+)$/u', $base, $m)) {
            $emoji = trim($m[1]);
            $base = rtrim(mb_substr($base, 0, mb_strlen($base) - mb_strlen($m[1])));
        }
        // اگر پایه سوالی است، جملهٔ دوم بدون نقطه‌گذاری عجیب بچسبد
        if (preg_match('/[؟?]\s*$/u', $base)) {
            return rtrim($base, ' ') . ' ' . $extra . ($emoji !== '' ? ' ' . $emoji : '');
        }
        $r = mt_rand(1,100);
        if ($r <= 45) $out = rtrim($base, '.!…؟?') . '، ' . $extra;
        elseif ($r <= 62) $out = $base . ' — ' . $extra;
        elseif ($r <= 76) $out = rtrim($base, '.!…؟?') . '… ' . $extra;
        elseif ($r <= 88 || $is_lyric) $out = rtrim($base, '.!…؟?') . '. ' . $extra;
        else $out = $base . '، ' . $extra;
        return $emoji !== '' ? $out . ' ' . $emoji : $out;
    }

    // تولید متن کامنت — طبیعی مثل رز موزیک / موزیکس-فا (تحلیل 12 نمونه واقعی) — کوتاه، کشیده، غلط ریز، بدون تکرار
    /**
     * متن یکتا برای همین پست — به‌جای چسباندن عدد تصادفی به انتهای کامنت،
     * دوباره تولید می‌کند و اگر نتوانست، رشتهٔ خالی برمی‌گرداند (کامنت تکراری نگذار).
     */
    public static function unique_text(int $post_id, string $artist, string $title, int $weight, int $views, bool $is_premium = false, int $tries = 6): string {
        global $wpdb;
        $tries = max(1, min(12, $tries));
        for ($n = 0; $n < $tries; $n++) {
            $txt = self::generate_text($post_id, $artist, $title, $weight, $views, $is_premium);
            $txt = trim((string)$txt);
            if ($txt === '') continue;
            $exists = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_post_ID=%d AND comment_content=%s",
                $post_id, $txt
            ));
            if (!$exists) return $txt;
        }
        return '';
    }

    public static function generate_text(int $post_id, string $artist, string $title, int $weight, int $views, bool $is_premium = false): string {
        $orig_weight = $weight; $orig_views = $views;
        // منتخب ویژه — وزن موثر 95 برای پرفکت بودن (حتی اگر خواننده نوپا باشد)
        if ($is_premium) { $weight = max($weight, 95); $views = max($views, 800000); }
        // سن پست برای کامنت هوشمند — موزیک جدید نباید انتقاد قدیمی بخورد
        $post_age_days = null;
        if ($post_id) {
            $d = get_post_field('post_date_gmt', $post_id);
            if ($d) $post_age_days = (time() - strtotime($d . ' GMT')) / DAY_IN_SECONDS;
            // اگر پست فاقد تاریخ بود، آن را متوسط در نظر بگیر
            else $post_age_days = 100;
        }
        $clean = self::clean_song_title($title, $artist);
        // 35% AI (با لحن جدید طبیعی) ، 65% fallback محلی غیرتکراری
        $use_ai = (mt_rand(1,100) <= 35);
        $txt = null;
        if ($use_ai) $txt = self::generate_via_ai($artist, $clean, $weight, $views, $post_age_days, $post_id);
        if (!$txt) $txt = self::fallback_text($weight, $views, $clean, $is_premium, $post_id, $post_age_days, $artist);
        // ضد تکرار سراسری: اگر این متن اخیراً استفاده شده، دوباره بساز
        $tries = 0;
        while (self::is_recent_duplicate($txt, $post_id) && $tries < 4) {
            $txt = self::fallback_text($weight, $views, $clean, $is_premium, $post_id, $post_age_days, $artist);
            $tries++;
        }
        self::remember_text($txt);
        // نکته: اسم آهنگ به‌صورت پیش‌فرض در کامنت نمی‌آید (تنظیم «نام آهنگ در کامنت»)
        // نهایی: یا کشیده‌نویسی یا یک غلط ریز (نه هر دو روی هم — خروجی خراب نشود)
        $style_roll = mt_rand(1,100);
        if ($style_roll <= 17) $txt = self::elongate($txt);
        elseif ($style_roll <= 31) $txt = self::add_typo($txt);

        // ===== لایهٔ ارتباط: تعریف از خواننده / نام آهنگ / تیکهٔ ترانه =====
        // روی ترکیب قبلی سوار می‌شود و چیزی از پول‌های موجود را حذف نمی‌کند.
        $is_negative_final = self::looks_negative($txt);
        $ctype_final = self::detect_content_type($post_id, $title);
        $recog_final = self::artist_is_placeholder($artist) ? 'low' : self::recognition_level($weight, $views);
        $is_music = in_array($ctype_final, ['song','album','video'], true);
        $is_trend_final = function_exists('apex_omega_is_trend_post') && apex_omega_is_trend_post($post_id);
        // ناشناخته: تعریف از خواننده نمی‌چسبانیم و احتمال اشاره هم کمتر است
        // ترند: برعکس — آهنگ قدیمی و شناخته‌شده است، پس تقریباً همیشه به خواننده/آهنگ/تیکه اشاره می‌شود
        $rel_chance = $is_trend_final ? 35 : (($recog_final === 'low') ? 0 : 55);
        if ($is_trend_final) $is_music = true;
        if ($is_music && !$is_negative_final && mt_rand(1,100) <= $rel_chance && mb_strlen($txt) < 145 && !preg_match('/[A-Za-z]{5,}/u', $clean)) {
            $rel = self::relevance_line($post_id, $artist, $clean, $weight);
            if (!empty($rel['text'])) {
                $dup = false;
                if ($rel['type'] === 'title') {
                    $tt = self::title_short($clean);
                    if (mb_strlen($tt) >= 3 && mb_stripos($txt, $tt) !== false) $dup = true;
                } elseif ($rel['type'] === 'artist') {
                    $aa = self::artist_short($artist);
                    if (mb_strlen($aa) >= 3 && mb_stripos($txt, $aa) !== false) $dup = true;
                }
                if (!$dup) $txt = self::weave($txt, $rel['text'], $rel['type'] === 'lyric');
            }
        }
        return $txt;
    }

    private static function elongate(string $s): string {
        // فقط کلمات کامل و امن کشیده می‌شوند (هیچ‌وقت وسط کلمه) — مثل «عالییییی» واقعی
        $map = [
            'عالی' => 'عالیییی', 'عالیه' => 'عالیههه', 'خیلی' => 'خیلییی', 'محشره' => 'محشررره',
            'محشر' => 'محشررر', 'قشنگه' => 'قشنگهه', 'قشنگ' => 'قشنگگ', 'بهترینه' => 'بهترینهه',
            'خفنه' => 'خفنننه', 'حرف نداره' => 'حرف ندارهه',
            'آخرشه' => 'آخرشهه', 'زیبا' => 'زیباا',
        ];
        foreach ($map as $w => $rep) {
            $q = preg_quote($w, '/');
            if (preg_match('/(?<![\p{L}])' . $q . '(?![\p{L}])/u', $s)) {
                $out = preg_replace('/(?<![\p{L}])' . $q . '(?![\p{L}])/u', $rep, $s, 1);
                if (is_string($out) && $out !== $s) return $out;
            }
        }
        return $s;
    }
    private static function add_typo(string $s): string {
        // حداکثر یک تغییر کوچک — عمداً بدون کشیده‌کردن حروف (آن کار elongate است)
        if (mb_strpos($s, 'آهنگ') !== false && mt_rand(1,100) <= 55) {
            return str_replace('آهنگ', 'اهنگ', $s);
        }
        // نیم‌فاصلهٔ داخل نام/عنوان داخل گیومه دست‌نخورده بماند («شب‌های بی‌ستاره»)
        if (mb_strpos($s, '‌') !== false && !preg_match('/«[^»]{2,}»/u', $s) && mt_rand(1,100) <= 40) {
            return str_replace('‌', '', $s);
        }
        if (mt_rand(1,100) <= 22) {
            $s = rtrim($s, '.!؟?…');
            $ends = ['…', '....', '!!'];
            return $s . $ends[array_rand($ends)];
        }
        return $s;
    }
    // ضد تکرار سراسری — آخرین ۱۰۰۰ متن را نگه می‌دارد
    private static function recent_key(): string { return 'apex_omega_recent_comments'; }
    private static function is_recent_duplicate(string $txt, int $post_id): bool {
        $key = self::recent_key();
        $list = get_option($key, []);
        if (!is_array($list)) $list = [];
        $hash = md5(trim($txt));
        if (in_array($hash, $list, true)) return true;
        // همچنین چک داخل همین پست 24ساعت (قدیمی)
        global $wpdb;
        $dup = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_post_ID=%d AND comment_content=%s AND comment_date_gmt >= %s", $post_id, $txt, gmdate('Y-m-d H:i:s', time() - DAY_IN_SECONDS)));
        return !empty($dup);
    }
    private static function remember_text(string $txt): void {
        $key = self::recent_key();
        $list = get_option($key, []);
        if (!is_array($list)) $list = [];
        $hash = md5(trim($txt));
        array_unshift($list, $hash);
        // 1000 متن اخیر (قبلاً ۲۰۰) — تنوع بیشتر، تکرار کمتر
        $list = array_slice(array_unique($list), 0, 1000);
        update_option($key, $list, false);
    }

    private static function generate_via_ai(string $artist, string $title, int $weight, int $views, ?float $post_age_days = null, int $post_id = 0): ?string {
        $clean = self::clean_song_title($title, $artist);
        $settings = AI_Helper::get_settings();
        if (empty($settings['api_key'])) return null;
        // نوع محتوا اول مشخص شود — بیوگرافی/خبر هرگز لحن آهنگ نمی‌گیرد
        $ctype_ai = self::detect_content_type($post_id, $clean);
        // خبر/بیوگرافی: خودِ متن خوانده شود تا کامنت دربارهٔ همان خبر باشد نه یک جملهٔ کلی
        $facts_ai = [];
        $body_excerpt = '';
        if ($post_id && in_array($ctype_ai, ['bio','news'], true)) {
            $facts_ai = self::content_facts($post_id);
            $body = self::post_body_text($post_id, 900);
            if ($body !== '') {
                $body_excerpt = (mb_strlen($body) > 420) ? mb_substr($body, 0, 420) : $body;
            }
        }
        // لحن بر اساس تحلیل رز موزیک: کوتاه محاوره‌ای، نه رسمی (2-7 کلمه ایده‌آل 60%) — با توجه به تازگی پست
        $is_new_ai = ($post_age_days !== null && $post_age_days < 60);
        $roll = mt_rand(1,100);
        if ($is_new_ai) {
            // برای موزیک تازه (<60 روز) احتمال انتقاد را از 15% به 5% کم کن و هرگز «قدیمی» نگو
            if ($roll <= 60) {
                $tone = 'کوتاه و محاوره‌ای مثبت مثل کامنت واقعی رز موزیک برای موزیک جدید: "ممنون عالی بود" "حرف نداره" "آخرشه" — 2 تا 6 کلمه، خودمونی، هیجان تازه‌گی، گاهی کشیده مثل "عالییییی"';
            } elseif ($roll <= 78) {
                $tone = 'اول سلام کوتاه بعد نظر مثبت برای موزیک تازه: "سلام دمت گرم عالی بود" "تبریک بابت موزیک جدید" — صمیمی';
            } elseif ($roll <= 83) {
                $tone = 'سوال فنی ملایم برای موزیک جدید (نه انتقاد قدیمی): "کاش کیفیت ۳۲۰ بهتر بود" "میکسش میتونست بهتر باشه" "متنشو دارید؟" — مودبانه، 4-8 کلمه، هرگز نگی قدیمیه/تکراریه';
            } else {
                $tone = 'احساسی-شخصی کوتاه برای موزیک جدید: "وایبش عالیه" "حس خوبی داره" — 5-10 کلمه، تازه‌گی';
            }
        } else {
            if ($roll <= 55) {
                $tone = 'کوتاه و محاوره‌ای مثل کامنت واقعی رز موزیک: "ممنون عالی بود" "حرف نداره" "آخرشه" — 2 تا 6 کلمه، خودمونی، بدون نقطه‌گذاری کامل، گاهی کشیده مثل "عالییییی"';
            } elseif ($roll <= 70) {
                $tone = 'اول سلام کوتاه بعد نظر: "سلام دمت گرم عالی بود" — صمیمی';
            } elseif ($roll <= 85) {
                $tone = 'انتقاد ملایم یا سوال کوتاه: "چرا اهنگای قدیمی میذارین؟" "کاش کیفیت بهتر بود" "سایت یکم کند لود میشه" — مودبانه ولی انتقادی، 4-8 کلمه';
            } else {
                $tone = 'احساسی-شخصی کوتاه: "یاد بچگیم افتادم" "با این اهنگ خاطره دارم" — 5-10 کلمه';
            }
        }
        // نمونه‌های واقعی برای few-shot (نه کپی، فقط الگو طول/لحن) — برای تازه مثال قدیمی حذف شود
        if ($is_new_ai) {
            $examples = 'نمونه طول/لحن برای موزیک جدید (کپی نکن، فقط الگو): "ممنون عالی بود" / "آخرشه حرف نداره" / "عالییییییی تازه‌ست" / "محشره محسن جان ۲۰👌" / "تبریک بابت موزیک جدید" / "کیفیتش عالیه دمت گرم" / "وایبش حرف نداره…" / "بهترین اهنگشه به نظرم 😍"';
        } else {
            $examples = 'نمونه طول/لحن (کپی نکن، فقط الگو بگیر): "ممنون عالی بود" / "آخرشه حرف نداره" / "عالییییی" / "محشره محسن جان ۲۰👌" / "زیبا بود ارمش گرفتم" / "چرا اهنگای قرن بوقی میذارین؟؟؟" / "خیلییی قشنگه متنشم قشنگه…" / "بهترین اهنگشه به نظرم 😍"';
        }
        // بیوگرافی و خبر: لحن و نمونه‌ها باید از جنس متن باشند نه آهنگ
        if ($ctype_ai === 'bio') {
            $tone = 'نظر کوتاه دربارهٔ یک بیوگرافی/مقاله: "ممنون از این مطلب کامل" "کاش بخش شروع کارش کامل‌تر بود" "این اطلاعات از منبع موثقه؟" "خیلی چیزا یاد گرفتم" — 3 تا 10 کلمه، محاوره‌ای ولی محترمانه';
            $examples = 'نمونه‌ها (کپی نکن): "ممنون از بیوگرافی کاملش" / "کاش درباره شروع کارش بیشتر می‌نوشتید" / "سال تولدش اشتباه نوشته شده" / "نمی‌دونستم اینقدر سابقه داره" / "منبعش ویکی‌پدیاست؟" / "لطفا بقیه خواننده‌ها هم"';
        } elseif ($ctype_ai === 'news') {
            $tone = 'نظر کوتاه دربارهٔ یک خبر: "منبعش کجاست؟" "امیدوارم شایعه باشه" "منتظر تایید رسمی‌ام" "بالاخره یه خبر خوب" — 3 تا 10 کلمه، محاوره‌ای و بی‌طرف';
            $examples = 'نمونه‌ها (کپی نکن): "منبع خبر کجاست؟" / "امیدوارم شایعه باشه" / "بالاخره یه خبر خوب" / "کاش تاریخ دقیق رو می‌نوشتید" / "این خبر قدیمیه" / "تا تایید رسمی باور نمی‌کنم"';
        }
        // لحن اختصاصی هر نوع محتوا
        if ($ctype_ai === 'bio') {
            $type_rule = 'این صفحه بیوگرافی/زندگی‌نامهٔ خواننده است، نه آهنگ. دربارهٔ زندگی، شروع کار، آلبوم‌ها یا اطلاعات متن نظر بده؛ می‌توانی منبع را زیر سوال ببری یا بخواهی بخشی کامل‌تر شود («منبعش کجاست؟»، «کاش بخش شروع کارش کامل‌تر بود»). هرگز دربارهٔ ریتم یا ملودی یک آهنگ خاص حرف نزن.';
        } elseif ($ctype_ai === 'news') {
            $type_rule = 'این یک خبر یا اطلاعیه است، نه آهنگ. دربارهٔ خود خبر نظر بده: منبع، تایید رسمی، انتظار یا بدبینی ملایم («منبعش کجاست؟»، «امیدوارم شایعه باشه»، «منتظر تایید رسمی‌ام»). تعریف از آهنگ نکن.';
        } elseif ($ctype_ai === 'album') {
            $type_rule = 'این یک آلبوم است. می‌توانی از ترک‌ها، ترتیبش، کاور یا کیفیت کلی آلبوم بگویی («ترک ۴ حرف نداره»، «ترتیب ترک‌ها خوب چیده شده»).';
        } elseif ($ctype_ai === 'video') {
            $type_rule = 'این یک موزیک‌ویدیو یا کلیپ است. دربارهٔ تصویر، کارگردانی، لوکیشن یا تدوین هم می‌توانی نظر بدهی («کلیپش قشنگ شده»، «کارگردانش کیه؟»).';
        } else {
            $type_rule = '';
        }
        // تیکهٔ واقعی ترانه (اگر موجود باشد) + نام خواننده/آهنگ برای اشارهٔ طبیعی
        $hook = ($ctype_ai === 'bio' || $ctype_ai === 'news') ? '' : self::extract_lyric_hook($post_id);
        $hook_hint = $hook !== '' ? ' تیکهٔ ترانهٔ واقعی این آهنگ: «'.$hook.'» — اگر خواستی فقط همین را نقل کن، چیزی از خودت به‌عنوان شعر نساز.' : '';
        $rel_roll = mt_rand(1,100);
        if ($ctype_ai === 'bio' || $ctype_ai === 'news') {
            $rel_rule = $type_rule;
        } elseif ($rel_roll <= 40) {
            $rel_rule = 'در این کامنت حتماً به‌طور طبیعی از خواننده ('.$artist.') تعریف کن، مثلا «دمت گرم '.self::artist_first_word($artist).'» یا «صدای '.self::artist_short($artist).' آرامشه» — خودمونی و کوتاه.';
        } elseif ($rel_roll <= 65 && self::mention_title_enabled() && mb_strlen(self::title_short($clean)) >= 3) {
            $rel_rule = 'در این کامنت اسم آهنگ («'.self::title_short($clean).'») را طبیعی بیاور و تعریف کن، مثل «'.self::title_short($clean).' رو چند بار گوش دادم».';
        } else {
            $rel_rule = 'در این کامنت به تیکه/متن ترانه اشاره کن و بگو کدام قسمت به دلت نشست.'.$hook_hint;
        }
        $is_trend_ai = function_exists('apex_omega_is_trend_post') && apex_omega_is_trend_post($post_id);
        if ($is_trend_ai && $ctype_ai === 'song') {
            $type_rule = 'این آهنگ در دستهٔ «آهنگ‌های ترند» است و معمولاً قدیمی و وایرال شده؛ لحن باید نوستالژی و هیجان «چرا تازه ترند شد؟» باشد («این آهنگ یه زمان همه‌جا بود»، «حقش بود ترند بشه»، «نسل ما با این بزرگ شد»). در همین کامنت اسم خواننده را طبیعی بیاور.';
            if (self::mention_title_enabled()) $type_rule = rtrim($type_rule, '.') . ' اسم آهنگ را هم می‌توانی بیاوری.';
            $lyric_rule_hint = true;
        } else {
            $lyric_rule_hint = false;
        }
        $recog_ai = self::recognition_level($weight, $views);
        $known_rule = ($recog_ai === 'low' && !$is_trend_ai)
            ? ' این خواننده یا اثر شناخته‌شده نیست؛ پس تعریف بی‌جا و بزرگ‌نمایی نکن. طبیعی‌تر است کنجکاو باشی یا بی‌طرف نظر بدهی («اولین باره اسمشو می‌شنوم، بد نبود»، «برای شروع بد نیست») و حداکثر یک ایراد کوچک بگیری.'
            : '';
        // اسم آهنگ به مدل داده نمی‌شود مگر تنظیمش روشن باشد — مدل نباید اسم را در کامنت تکرار کند
        $title_for_prompt = self::mention_title_enabled() ? $clean : '';
        if ($ctype_ai === 'bio') {
            $subject = $body_excerpt !== ''
                ? 'برای صفحهٔ بیوگرافی "'.$clean.'" دربارهٔ "'.$artist.'". متن بیوگرافی: "'.$body_excerpt.'"'
                : 'برای صفحهٔ بیوگرافی "'.$clean.'" دربارهٔ "'.$artist.'"';
        } elseif ($ctype_ai === 'news') {
            $subject = $body_excerpt !== ''
                ? 'برای این خبر دربارهٔ "'.$artist.'": "'.$body_excerpt.'"'
                : 'برای خبر "'.$clean.'" دربارهٔ "'.$artist.'"';
        } elseif ($ctype_ai === 'album') {
            $subject = 'برای آلبوم "'.$clean.'" از "'.$artist.'"';
        } elseif ($title_for_prompt !== '') {
            $subject = 'برای اهنگ "'.$clean.'" از "'.$artist.'"';
        } else {
            $subject = 'برای صفحهٔ آهنگ "'.$artist.'" (اسم آهنگ را در کامنت ننویس)';
        }
        $lyric_rule = ($ctype_ai === 'bio' || $ctype_ai === 'news')
            ? '4) دربارهٔ آهنگ، ریتم یا ملودی حرف نزن؛ اگر اطلاعات متن ناقص است، طبیعی است که منبع یا تکمیل آن را بخواهی'
            : '4) هرگز شعر جعلی نساز؛ اگر تیکهٔ ترانه را نمی‌دانی، فقط تماتیک اشاره کن («اون تیکه که از دلتنگی میگه»)';
        $prompt = "تو یک کاربر سایت رز موزیک/موزیکس‌فا هستی. ".$subject." یک کامنت کوتاه فارسی محاوره‌ای بنویس. $tone — $examples — $rel_rule — قوانین: 1) فارسی محاوره‌ای 2-12 کلمه ترجیحا، حداکثر 18 کلمه 2) گاهی غلط ریز مثل اهنگ بجای آهنگ، کشیده مثل خیلییییی، بدون نگارش رسمی کامل 3) گاهی ایموجی ساده ❤️😍👌 ولی نه همیشه (20% مواقع) ".$lyric_rule." 5) بدون هشتگ/انگلیسی/گیومه/دانلود — فقط متن کامنت.".($title_for_prompt === '' ? ' 6) اسم آهنگ را در کامنت ننویس؛ کاربری که در صفحهٔ همین آهنگ است اسمش را تکرار نمی‌کند.' : '').(in_array($ctype_ai, ['bio','news'], true) ? ' 7) حتماً به یک جزئیات مشخص از همین متن اشاره کن (شهر، سال، نام آلبوم/آهنگ داخل گیومه، کنسرت، همکاری). جمله‌های کلی و بی‌ربط مثل «منبع خبر کجاست؟» یا «امیدوارم شایعه باشه» را هرگز ننویس — منبع در همین متن ذکر شده است.' : '').$known_rule;
        $payload = [
            'model' => $settings['model'] ?: 'gpt-4o-mini',
            'messages' => [
                ['role'=>'system','content'=>'تو کاربر ایرانی سایت موزیک هستی. فقط یک کامنت کوتاه محاوره‌ای برگردان، نه رسمی و نه طولانی.'],
                ['role'=>'user','content'=>$prompt],
            ],
            'temperature'=>0.95,
            'max_tokens'=>60,
        ];
        $resp = wp_remote_post($settings['endpoint'], [
            'headers'=>['Authorization'=>'Bearer '.$settings['api_key'],'Content-Type'=>'application/json'],
            'body'=>wp_json_encode($payload, JSON_UNESCAPED_UNICODE),
            'timeout'=>10,
        ]);
        if (is_wp_error($resp)) return null;
        $body = wp_remote_retrieve_body($resp);
        $data = json_decode($body, true);
        $content = $data['choices'][0]['message']['content'] ?? '';
        $content = trim($content);
        // تمیزکاری: حذف نقل قول و هشتگ
        $content = trim($content, " \t\n\r\0\x0B\"'«»");
        $content = preg_replace('/^["\'«»]+|["\'«»]+$/u', '', $content);
        $content = preg_replace('/#\S+/u', '', $content);
        $content = trim($content);
        if (!$content || mb_strlen($content) < 2 || mb_strlen($content) > 180) return null;
        // خبر/بیوگرافی: اگر به هیچ جزئیات همین متن اشاره نکرد، رد شود تا نسخهٔ مبتنی بر متن ساخته شود
        if (!empty($facts_ai) && !empty($facts_ai['raw_len'])) {
            $tokens = [];
            foreach ([$facts_ai['city'] ?? '', $facts_ai['style'] ?? '', $facts_ai['topic'] ?? ''] as $tok) {
                if (is_string($tok) && mb_strlen($tok) >= 3) $tokens[] = $tok;
            }
            foreach (($facts_ai['years'] ?? []) as $y) $tokens[] = (string)$y;
            foreach (($facts_ai['quoted'] ?? []) as $q) $tokens[] = (string)$q;
            $hit = false;
            foreach ($tokens as $tok) {
                if ($tok !== '' && mb_stripos($content, $tok) !== false) { $hit = true; break; }
            }
            if (!$hit) return null;
        }
        // هیچ لینک/تبلیغی در کامنت نباشد (ریسک اسپم برای سئو)
        if (preg_match('/https?:|www\.|\.(?:com|ir|net|org)\b|\bدانلود\b|\bلینک\b|\bhref\b/iu', $content)) return null;
        // اسم آهنگ در خروجی مدل هم کنترل می‌شود (پرامپت کافی نیست)
        if (!self::mention_title_enabled()) {
            $tt_ai = self::title_short($clean);
            if ($tt_ai !== '' && mb_strlen($tt_ai) >= 3) {
                $content = str_ireplace(['«'.$tt_ai.'»', '"'.$tt_ai.'"', $tt_ai], '', $content);
                $content = trim(preg_replace('/\s{2,}/u', ' ', $content));
                $content = self::trim_sep($content, '«»""،,.:;');
            }
        }
        // اگر خیلی رسمی/طولانی بود (بیش از 12 کلمه و با نقطه پایان رسمی)، کوتاه کن
        $words = preg_split('/\s+/u', $content);
        if (count($words) > 14 && mb_strlen($content) > 70) {
            // 40% مواقع ببرش 8-10 کلمه
            if (mt_rand(1,100) <= 40) $content = implode(' ', array_slice($words, 0, mt_rand(6,10)));
        }
        return $content;
    }


private static function fallback_text(int $weight, int $views, string $title = '', bool $is_premium = false, int $post_id = 0, ?float $post_age_days = null, string $artist = ''): string {
        // سن پست را محاسبه کن برای فیلتر کامنت‌های نامناسب (مثل «چرا قدیمی میذارین» برای موزیک جدید)
        if ($post_age_days === null && $post_id) {
            $d = get_post_field('post_date_gmt', $post_id);
            if ($d) $post_age_days = (time() - strtotime($d . ' GMT')) / DAY_IN_SECONDS;
        }
        // الهام از رز موزیک (12 نمونه) و موزیکس-فا — نه کپی، بلکه آنالیز طول/لحن/غلط
        // الگوها: 2-5 کلمه کوتاه 40%، محاوره کوتاه 25%، انتقادی/سوالی 15%، شخصی-خاطره‌ای 10%، طولانی‌ احساسی 10%
        // غلط‌ها: اهنگ بجای آهنگ (شایع)، کشیده عالییی/خیلییی، نقطه … ؟؟، نیم‌فاصله حذف
        $ultra_short = [
            'ممنون عالی بود', 'حرف نداره', 'آخرشه', 'عالی بود', 'محشره', 'دوسش دارم', 'خیلی قشنگه', 'بهترینه', 'عالیهه', 'قشنگ بود',
            'دمت گرم', 'عشقی', 'حرف نداره واقعا', 'آخرشه واقعا', 'عالی بود مرسی', 'محشر بود', 'خفن بود', 'دوست داشتنیه', 'زیبا بود',
            'مرسی عالی', 'عالییی', 'خیلییی خوبه', 'عالیههه', 'محشررره', 'قشنگهه', 'دوس داشتنیه', 'خفنه', 'عالی بود دمت گرم',
            'ممنون قشنگ بود', 'عالییییی', 'خیلییی قشنگه', 'محشره واقعا', 'عالی بود خیلی', 'قشنگ بود مرسی',
        ];
        $short_colloquial = [
            'هم ریتمش هم متنش عالی', 'صداش حرف نداره', 'متنش خیلی قشنگه', 'ریتمش عالیه', 'اهنگ قشنگیه واقعا',
            'خیلی اهنگ قشنگیه', 'دمتون گرم عالی بود', 'محشره عالی هست', 'عالیه دمتون گرم', 'خیلی دوسش دارم',
            'اهنگش محشره', 'واقعا زیبا بود', 'عالی بود مرسی ازتون', 'دستتون درد نکنه', 'خسته نباشید عالی بود',
            'خیلی خوب بود مرسی', 'قشنگ بود ممنون', 'عالی بود لذت بردم', 'صداتون حرف نداره', 'ترانه قشنگیه',
            'ملودیش حرف نداره', 'ریتمش خیلی قشنگه', 'خوشم اومد واقعا', 'عالی خوندید', 'حسش عالی بود',
            'ارمش گرفتم ممنون', 'اروم شدم باهاش', 'یاد قدیما افتادم', 'حس خوبی داره', 'دلنشینه واقعا',
        ];
        $medium_natural = [
            'اهنگ دلنشینی بود لذت بردم', 'صداتون به دل میشینه خسته نباشید', 'ملودی قشنگی داره ممنون', 'ترانه احساسی بود موفق باشید',
            'صدای گرمتون شنیدنیه', 'کار تمیزی بود امیدوارم بیشتر بشنویم', 'حس و حال خوبی داشت', 'تنظیمش به دل میشینه',
            'با احساس خوندید عالی بود', 'قطعه ارومش بخشی بود', 'با عشق اجرا شده مشخصه', 'ممنون بابت این قطعه',
            'حس خوبی بهم داد مرسی', 'خیلی وقت بود منتظرش بودم', 'هر بار گوش میدم بیشتر دوستش دارم', 'حالش خیلی خاصه',
            'یکی از بهترین کاراتونه', 'اجراتون فوق العاده بود', 'وایب اهنگ خیلی قشنگه', 'این قطعه لایق شنیده شدنه',
            'چقدر با احساس خوندید', 'ملودی گیرا و قشنگه', 'ترانه و تنظیم هر دو خوب بودن', 'ارومش بخش بود واقعا',
        ];
        $critical_question = [
            'چرا اهنگای قدیمی میذارین؟؟', 'کاش کیفیت 320 بهتر بود', 'تبلیغات سایت زیاده اذیت میکنه', 'پخش انلاین گیر میکنه گاهی',
            'کاش متن اهنگم میذاشتین', 'چرا اهنگای تکراری میذارید', 'کیفیتش متوسط بود', 'میکسش میتونست بهتر باشه',
            'شعرش یه جاش ضعیف بود', 'انتظار بیشتری داشتم ولی خوبه', 'سایت خوبه ولی دیر لود میشه', 'کاش نسخه ریمیکس هم بذارید',
            'اهنگ قشنگه ولی قدیمیه یکم', 'کاورش قشنگ نیست ولی اهنگ خوبه', 'چرا اهنگای قرن بوقی میذارین؟؟؟',
            'پخشش یکم با تاخیر لود میشه', 'تبلیغات یکم زیاده', 'کاش اهنگ جدیدتر بذارید', 'کی منتشر شده کسی میدونه؟',
            'کسی متن اهنگو داره؟', 'نظرتون چیه بچه ها؟', 'این اهنگ جدیدشه؟', 'متنشو دارید؟', 'اهنگ شاد ندارید؟',
            'کاش اهنگ شادم بذارید', 'صداش یکم ضعیف میکس شده', 'ریتمش تکراریه یکم', 'شعرش میتونست قویتر باشه',
        ];
        $personal = [
            'من و عشقم داریم جدا میشیم این اهنگ وصف حالمونه 🙁', 'یاد بچگیم افتادم با این اهنگ', 'هر وقت ناراحتم اینو گوش میدم اروم میشم',
            'با این اهنگ خاطره دارم خیلی', 'بهترین اهنگشه به نظرم باعث افتخارمونه 😍', 'این اهنگ منو یاد قدیما میندازه',
            'دارم با این اهنگ گریه میکنم', 'شبام با این اهنگ میگذره', 'عاشق این اهنگم هر روز گوش میدم',
            'خاطره دارم باهاش خیلی دوسش دارم', 'یاد عشق قدیمم افتادم', 'با عشقم با این اهنگ اشنا شدیم', 'هر وقت میشنوم دلم میگیره',
            'خیلی وقت بود دنبالش بودم مرسی', 'واقعا به دلم نشست', 'ارامش گرفتم باهاش ممنون', 'حالم باهاش خوب میشه',
        ];
        // برای هنرمند ناشناخته: «شخصی/احساسی» هم نباید تعریف بزرگ باشد
        $personal_neutral = [
            'اولین باره می‌شنومش، ببینم بعدا چی میشه', 'این اولین کارشه؟', 'یه بار گوش دادم، نظر خاصی ندارم',
            'باید چند بار گوش بدم تا نظرم عوض بشه', 'هنوز نمی‌دونم دوستش دارم یا نه', 'با این کارش نظرم عوض نشد',
            'کسی معرفیش کرده؟', 'از کجا اومده یهو؟', 'اسمش برام ناآشناست', 'فکر کنم تازه شروع کرده',
            'استعدادش هست، هنوز پخته نیست', 'باید بیشتر کار بده تا بشناسیمش',
        ];
        $long_emotional = [
            'به جرات میتونم بگم بهترین اهنگشه باعث افتخارمونه همشهری 😍', 'متنش هم قشنگه ریتمش هم عالیه واقعا لذت بردم',
            'هم ریتمش هم متنش هم صداش عالیه واقعا محشره', 'خیلی اهنگ قشنگیه متنش هم قشنگه دمش گرم',
            'صداش معرکه است این قطعه خاص شده واقعا', 'هر ثانیه‌ش پر از احساس بود ممنون بابت این اثر',
            'واقعا شاهکاره صدا و حس بی نظیره', 'این قطعه بی تردید ماندگار میشه', 'اجرای فوق العاده بود تبریک میگم',
            'ترانه به یاد موندنی با تنظیمی خوب', 'بی نهایت لذت بردم جزو بهتریناست', 'صداتون معجزه میکنه',
        ];
        // برای هنرمند ناشناخته: همین طول ولی لحن بی‌طرف/منتقدانه‌تر (نه «بهترین آهنگشه»)
        $long_neutral = [
            'بد نبود، ولی هنوز جا داره بهتر بشه', 'برای شروع خوبه، منتظر کارای بعدیشم',
            'صدا داره ولی تنظیم ضعیف‌تر از حد انتظار بود', 'کاش میکسش تمیزتر بود',
            'یه چیز تازه بود، ارزش یه بار گوش دادن رو داشت', 'هنوز سبک خودش رو پیدا نکرده',
            'استعداد داره، فقط باید بیشتر کار کنه', 'نسبت به کارای مشابهش متوسط بود',
            'شنیدنی بود، ولی تو ذهنم نمی‌مونه', 'تلاشش قابل تقدیره ولی راه زیاد داره',
            'ازش انتظار بیشتری داشتم راستش', 'قابل قبوله، ولی هنوز آماتوره',
        ];

        // تشخیص تازگی پست برای کامنت هوشمند — موزیک جدید نباید «چرا قدیمی میذارین» بخورد
        $is_new_post = ($post_age_days !== null && $post_age_days < 60);
        $is_mid_post = ($post_age_days !== null && $post_age_days >= 60 && $post_age_days < 180);
        $is_old_post = ($post_age_days !== null && $post_age_days >= 180);
        // فیلتر دسته انتقادی بر اساس سن — برای تازه‌ها فقط انتقاد فنی/سایتی، نه قدیمی بودن
        if ($is_new_post) {
            // برای موزیک تازه (کمتر از 60 روز) انتقادهای مربوط به قدیمی/تکراری حذف شود
            $critical_question = array_values(array_filter($critical_question, function($c){
                $bad = ['قدیمی','قرن بوقی','تکراری','قدیمیه یکم','جدیدتر بذارید'];
                foreach ($bad as $b) if (mb_strpos($c, $b) !== false) return false;
                return true;
            }));
            // اگر فیلتر همه را حذف کرد (نادر) fallback به سوالی عمومی
            if (empty($critical_question)) $critical_question = ['کاش کیفیت 320 بهتر بود','سایت یکم کند لود میشه','میکسش میتونست بهتر باشه'];
        } elseif ($is_mid_post) {
            // 60-180 روز: نصف انتقاد قدیمی حذف (کمتر حساس)
            if (mt_rand(1,100) <= 50) {
                $critical_question = array_values(array_filter($critical_question, function($c){
                    $soft_bad = ['قرن بوقی','قدیمی میذارین'];
                    foreach ($soft_bad as $b) if (mb_strpos($c, $b) !== false) return false;
                    return true;
                }));
            }
        }
        // وزن/بازدید → انتخاب وزن pool (نه همه مثبت! 15% انتقاد حتی برای پرطرفدار — ولی برای تازه کمتر)
        $is_premium_effective = $is_premium;
        $is_low = ($weight < 30 && $views < 15000);
        $is_high = ($weight >= 75 || $views >= 400000);
        $roll = mt_rand(1,100);
        // برای موزیک تازه احتمال انتقاد را از 15% به 7% کم کن + سوالی سبک بیشتر شود
        $critical_chance = $is_new_post ? 7 : 15; // درصد ورود به critical
        // محاسبه آستانه: ultra 38% + colloquial 24% = 62% → بعد critical 7/15% → بقیه personal/medium/long

        // نوع محتوا و سطح شناخته‌شدن هنرمند — بیوگرافی/خبر کامنت آهنگ نمی‌گیرد، ناشناخته سیل تعریف نمی‌گیرد
        $ctype = self::detect_content_type($post_id, $title);
        $recog = self::recognition_level($weight, $views);
        // بدون نام خواننده، تعریف از «هنرمند» بی‌معنی است → لحن محتاط/بی‌طرف
        if (self::artist_is_placeholder($artist)) $recog = 'low';

        if ($ctype !== 'song') {
            // بیوگرافی/خبر/آلبوم/ویدیو: از استخر مخصوص خودش، غالباً سوالی و بی‌طرف
            $tpool = self::typed_pool($ctype, $recog, $is_premium, $is_new_post, (int)$post_id, (string)$artist);
            // اگر متن پست فکت دارد، سهم جمله‌های عمومی کم شود تا کامنت دربارهٔ همان متن باشد
            $facts_have = false;
            if ($post_id) {
                $fx = self::content_facts($post_id);
                $facts_have = !empty($fx['raw_len']) && (
                    ($fx['city'] ?? '') !== '' || ($fx['year'] ?? '') !== '' || ($fx['topic'] ?? '') !== ''
                    || ($fx['style'] ?? '') !== '' || !empty($fx['quoted'])
                );
            }
            $roll2 = mt_rand(1,100);
            if ($ctype === 'bio' || $ctype === 'news') {
                // این نوع محتوا سیل تعریف ندارد و هیچ‌وقت جملهٔ موزیکی نمی‌گیرد
                $short_pos = ($ctype === 'bio')
                    ? ['ممنون از این مطلب', 'خوب نوشته شده', 'عالی بود مرسی', 'کامل و دقیق بود', 'دستتون درد نکنه',
                       'خیلی مفید بود', 'خسته نباشید', 'مطلب خوبی بود', 'به کارم اومد', 'مرسی از زحمتتون']
                    : ['ممنون از خبر', 'خبر خوبی بود', 'مرسی از اطلاع‌رسانی', 'دمتون گرم', 'بالاخره',
                       'خبر داغ بود', 'منتظر ادامه‌شیم', 'خوب بود', 'ممنون که گفتید', 'دستتون درد نکنه'];
                if ($roll2 <= ($facts_have ? 4 : 22)) $pool = $short_pos;
                else $pool = $tpool;
            } else {
                // آلبوم/ویدیو: تعریف کوتاه عمومی + استخر مخصوص خودش (بدون «آهنگش محشره» نامربوط)
                if ($roll2 <= ($facts_have ? 3 : 12)) $pool = $ultra_short;
                else $pool = $tpool;
            }
        } elseif ($is_premium_effective) {
            // پرفکت: 35% کوتاه، 40% محاوره، 15% شخصی، 10% متوسط — بدون انتقاد
            if ($roll <= 35) $pool = $ultra_short;
            elseif ($roll <= 65) $pool = $short_colloquial;
            elseif ($roll <= 80) $pool = $personal;
            elseif ($roll <= 92) $pool = $medium_natural;
            else $pool = $long_emotional;
        } elseif ($recog === 'low') {
            // هنرمند ناشناخته: تعریف کم، بی‌طرف/سوالی و انتقاد ملایم بیشتر — همه هم مثبت نه
            $crit_end = $is_new_post ? 30 : 40;
            if ($roll <= 8) $pool = $ultra_short;
            elseif ($roll <= 20) $pool = $short_colloquial;
            elseif ($roll <= $crit_end) $pool = $critical_question;
            elseif ($roll <= ($crit_end + 26)) $pool = self::typed_pool('song', 'low'); // بی‌طرف/«نشنیده بودم»
            elseif ($roll <= ($crit_end + 33)) $pool = $personal_neutral;
            elseif ($roll <= ($crit_end + 39)) $pool = $medium_natural;
            else $pool = $long_neutral;
        } else {
            // آستانه پویا بر اساس تازگی
            $crit_end = 62 + $critical_chance; // مثلا تازه: 69، قدیمی: 77
            $personal_end = $crit_end + 10; // 10% شخصی
            $medium_end = $personal_end + 6; // 6% متوسط
            if ($roll <= 38) {
                $pool = $ultra_short;
            } elseif ($roll <= 62) {
                $pool = $short_colloquial;
            } elseif ($roll <= $crit_end) {
                $pool = $critical_question; // انتقاد/سوال — برای تازه فیلتر و کمتر
            } elseif ($roll <= $personal_end) {
                $pool = $personal;
            } elseif ($roll <= $medium_end) {
                $pool = $medium_natural;
            } else {
                $pool = $long_emotional;
            }
        }
        // برای تازه‌ها بیشتر کوتاه، برای پرطرفدار بیشتر متوسط/طولانی ولی هنوز تنوع انتقاد حفظ شود
        if ($is_low && $roll > 80 && $ctype === 'song') $pool = $ultra_short;
        // if ($is_high && $roll <= 10) $pool = $critical_question; // حتی هیت‌ها انتقاد میخورند

        if ($ctype === 'bio' || $ctype === 'news') {
            // بیوگرافی/خبر: جملهٔ دوم باید از جنس متن باشد نه موزیک
            $natural_touch = [
                'خوب و روان نوشته شده', 'منبع خوبی انتخاب کردید', 'کاش کامل‌ترش می‌کردید',
                'چیزهای تازه‌ای دستگیرم شد', 'این مطلب رو ذخیره کردم', 'به دوستمم فرستادم بخونه',
                'همیشه از این مطالب بذارید', 'خیلی به‌روز نیست ولی خوبه', 'دقیق و بی‌طرف نوشته شده',
                'منتظرش بودم واقعا', 'بالاخره یه مطلب کامل', 'امیدوارم ادامه‌دار باشه',
            ];
        } else {
            $natural_touch = [
                'چند بار پشت سر هم گوش دادم', 'اینو تو پلی‌لیستم گذاشتم', 'از اون کاراست که خسته نمیشی',
                'با هدفون گوش بدید یه چیز دیگه‌ست', 'امروز از صبح همینو گوش میدم', 'حالم با این خوب شد',
                'دقیقا حالم رو خوب کرد', 'بعد از یه روز کاری چسبید', 'همین رو میخواستم امروز',
                'تنظیمش تمیزه', 'کیفیت میکسش خوبه', 'قسمت آرومش خیلی خوب دراومده',
                'به دوستمم فرستادم', 'توی ماشین فقط همین بود', 'اینو باید با صدای بلند گوش داد',
                'چقدر خوب شد که اومد', 'منتظرش بودم واقعا', 'دلم میخواست یه همچین کاری بیاد',
            ];
        }
        // آهنگ ترند: لحن وایرال/نوستالژی با نام خود خواننده و آهنگ (با بقیه قاطی نمی‌شود)
        $is_trend_post = function_exists('apex_omega_is_trend_post') && apex_omega_is_trend_post($post_id);
        if ($is_trend_post && empty($title) && $post_id) $title = (string) get_the_title($post_id);
        if ($is_trend_post && in_array($ctype, ['song','album','video'], true)) {
            // وزن تمرکز: ۳۵٪ نام آهنگ، ۳۰٪ نام خواننده، ۲۰٪ تیکهٔ ترانه، ۱۵٪ عمومی/وایرال
            $roll_t = mt_rand(1,100);
            $title_ok = self::mention_title_enabled();
            if ($roll_t <= 35 && $title_ok) $focus = 'title';
            elseif ($roll_t <= 65) $focus = 'artist';
            elseif ($roll_t <= 85) $focus = 'lyric';
            else $focus = 'generic';
            $pool = self::trend_pool($post_id, (string)$artist, (string)$title, $focus);
            if (!$pool) $pool = self::trend_pool($post_id, (string)$artist, (string)$title, 'generic');
            if (!$pool) $pool = $ultra_short;
        }
        $txt = $pool[array_rand($pool)];
        // کامنت انتقادی/سوالی نباید تعریف/ایموجی چسبیده بگیرد (طبیعی نیست)
        $is_negative = self::looks_negative($txt);
        // 14% یک جملهٔ طبیعی دوم — برای بیوگرافی/خبر نه (استخر خودشان لحن را دارد)
        $allow_touch = !($ctype === 'bio' || $ctype === 'news');
        if ($allow_touch && !$is_negative && mt_rand(1,100) <= 14 && mb_strlen($txt) < 70 && !in_array($txt, $natural_touch, true)) {
            $nt = $natural_touch[array_rand($natural_touch)];
            if (!self::repeats_praise($txt, $nt)) $txt = $txt . '، ' . $nt;
        }

        // 22% ایموجی سبک (نه زیاده) — هرگز روی کامنت انتقادی (طبیعی نیست)
        if (!$is_negative && mt_rand(1,100) <= 22) {
            $emojis = [' ❤️',' 👌',' 😍',' 🙏',' ✨',' 👏',' 😊',' 🔥'];
            $txt .= $emojis[array_rand($emojis)];
            // گاهی دو تایی مثل ۲۰👌👌 — فقط اگر ایموجی دیگری نباشد
            if (mt_rand(1,100) <= 10) {
                $txt = rtrim($txt);
                if (!preg_match('/[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}]/u', $txt)) $txt .= ' 20👌';
            }
        }
        // 12% ترکیب دو جمله کوتاه با هم (برای تنوع طول) — بدون تکرار و بدون چسبیدن به انتقاد
        if (!$is_negative && mt_rand(1,100) <= 12 && mb_strlen($txt) < 75) {
            $extra_pool = ($ctype === 'bio' || $ctype === 'news')
                ? ['ممنون از زحمتتون', 'به کارم اومد', 'منتظرش بودم', 'ادامه بدید', 'دقیق بود']
                : $ultra_short;
            $extra = $extra_pool[array_rand($extra_pool)];
            $head = mb_substr($extra, 0, 7);
            if ($extra !== $txt && mb_strpos($txt, $head) === false && !self::repeats_praise($txt, $extra)) {
                $hold = '';
                if (preg_match('/(\s*(?:[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}]\x{FE0F}?\s*)+)$/u', $txt, $m)) {
                    $hold = trim($m[1]);
                    $txt = rtrim(mb_substr($txt, 0, mb_strlen($txt) - mb_strlen($m[1])));
                }
                $txt .= ' ' . $extra . ($hold !== '' ? ' ' . $hold : '');
            }
        }
        // 10% بدون نقطه پایان — طبیعی (رز موزیک خیلی‌ها نقطه ندارند)
        if (mt_rand(1,100) <= 10) $txt = rtrim($txt, '.!؟?');

        return $txt;
    }

    public static function run_manual(): array {
        ob_start();
        $before = get_option('apex_omega_commentor_last_run', []);
        self::tick(true);
        $after = get_option('apex_omega_commentor_last_run', []);
        $log = ob_get_clean();
        return ['before'=>$before,'after'=>$after,'log'=>$log];
    }
    // تیک کامنت: کرون هر ۶ ساعت (گیت داخلی ۱ ساعت) — همهٔ پست‌ها بر اساس بازدید+امتیاز، gradual increase never decrease
    public static function tick(bool $verbose = false): void {
        if (!self::is_enabled()) return;
        // گیت ۱ساعته — فقط هر ۳۶۰۰ ثانیه اجرا شود (دستی verbose دور می‌زند)
        if (!$verbose) {
            $last = (int) get_option('apex_omega_commentor_last_tick_ts', 0);
            if ($last && (time() - $last < 3600)) return;
            update_option('apex_omega_commentor_last_tick_ts', time(), false);
        }
        $s = self::get_settings();
        $threshold = (int)$s['threshold'];
        $max_per_post = (int)$s['max_per_post'];
        $batch = (int)$s['batch'];
        $recent_days = (int)$s['only_recent_days'];
        $cooldown = (int)$s['cooldown_hours'] * HOUR_IN_SECONDS;
        $daily_growth = (int)$s['daily_growth'];

        global $wpdb;
        $where_recent = '';
        if ($recent_days > 0) {
            $cutoff = gmdate('Y-m-d H:i:s', time() - $recent_days * DAY_IN_SECONDS);
            // 1.8.9: پست‌های بدون کامنت حتی اگر قدیمی باشند نباید فیلتر شوند — خجالت‌آور است
            $where_recent = $wpdb->prepare(" AND (p.post_date_gmt >= %s OR NOT EXISTS (SELECT 1 FROM {$wpdb->comments} c0 WHERE c0.comment_post_ID = p.ID AND c0.comment_approved='1')) ", $cutoff);
        }
        // 2.1.0: گزینه خودکار برای پرطرفدارها >100k بدون دخالت انسانی
        $high_auto = !empty($s['high_views_auto']);
        $high_thr = (int)($s['high_views_threshold'] ?? 100000);
        $cooldown_bypass_sql = '';
        if ($high_auto) {
            $cooldown_bypass_sql = $wpdb->prepare(" OR CAST(pm.meta_value AS UNSIGNED) >= %d ", $high_thr);
        }
        // 1.8.7: برای هیت‌های میلیونی، recent_days سخت‌گیر نباش — اگر بازدید >500k حتی اگر قدیمی باشد شامل شود
        // این را در SQL جدا هندل می‌کنیم: اگر only_recent_days>0 ولی بازدید بالا باشد، اجازه بده
        // پس where_recent را برای هیت‌ها شل می‌کنیم در PHP بعداً (فعلا نگه می‌داریم اما در tick برای 657 چک ویژه داریم)
        // پیدا کردن پست‌های کاندید: همهٔ پست‌های منتشرشده که کامنت‌شان زیر سقف تیره است
        // اولویت با پست‌های تازه‌تر (post_date_gmt DESC) — مثل AutoWatch
        // 1.8.0: بدون سقف 20 — روزانه همهٔ پست‌های سایت بر اساس الگوی ریتم (بازدید+امتیاز+وزن)
        // batch=0 یعنی بدون LIMIT — روزانه همه
        // 1.9.0 حرفه‌ای: batch=0 یعنی همه ولی هر تیک 75تا (5×75=375 روزانه) — توازن سرعت/منابع
        $effective_batch = $batch > 0 ? $batch : ($verbose ? 120 : 55); // 2.1.1: manual 120/h برای پر کردن صفرها سریع‌تر، auto 55/h
        // 2.1.1 بک‌فیل سریع برای صفرها: اگر 80+ پست بدون کامنت داریم، بچ را افزایش بده
        $zero_cnt_check = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} p WHERE p.post_type='post' AND p.post_status='publish' AND NOT EXISTS (SELECT 1 FROM {$wpdb->comments} c WHERE c.comment_post_ID=p.ID AND c.comment_approved='1')");
        if ($zero_cnt_check > 80) {
            $effective_batch = min(150, $effective_batch + 60);
            if ($verbose) echo "zero backfill boost: zero=$zero_cnt_check batch=$effective_batch\n";
        }
        $limit_clause = $wpdb->prepare("LIMIT %d", $effective_batch);
        // 1.8.7: cooldown هوشمند — هیت‌ها زودتر دوباره کامنت بگیرند
        // برای پست‌های میلیونی cooldown را از 24h به 12h/6h کاهش می‌دهیم، پس cutoff را پویا می‌سازیم
        // در SQL اول با cooldown عمومی می‌گیریم، بعد در PHP اگر هیت بود و تازه cooldown شده، باز هم اجازه می‌دهیم
        $sql = "
            SELECT p.ID, p.post_title, p.post_date_gmt, COALESCE(CAST(pm.meta_value AS UNSIGNED), 0) as cur_views
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key='views'
            LEFT JOIN (SELECT comment_post_ID, COUNT(*) as c FROM {$wpdb->comments} WHERE comment_approved='1' GROUP BY comment_post_ID) cc ON cc.comment_post_ID = p.ID
            WHERE p.post_type='post' AND p.post_status='publish'
            {$where_recent}
            AND (
                NOT EXISTS (
                    SELECT 1 FROM {$wpdb->postmeta} pm2
                    WHERE pm2.post_id = p.ID
                    AND pm2.meta_key = %s
                    AND pm2.meta_value >= %s
                ){$cooldown_bypass_sql}
            )
            ORDER BY COALESCE(cc.c,0) ASC, p.post_date_gmt DESC, CAST(pm.meta_value AS UNSIGNED) DESC, p.ID DESC
            {$limit_clause}
        ";
        $cooldown_cutoff = gmdate('Y-m-d H:i:s', time() - $cooldown);
        $rows = $wpdb->get_results($wpdb->prepare($sql, self::META_LAST, $cooldown_cutoff), ARRAY_A);
        if ($verbose) echo "candidates:".count($rows)." | threshold:{$threshold} max_per:{$max_per_post} recent:{$recent_days} cooldown:{$cooldown_cutoff} effective_batch:{$effective_batch}\n";
        if (empty($rows)) {
            if ($verbose) {
                // دلیل یاب
                $total_posts = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='post' AND post_status='publish'");
                $with_cooldown = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key=%s AND meta_value >= %s", self::META_LAST, $cooldown_cutoff));
                echo "total_posts:{$total_posts} with_cooldown:{$with_cooldown} | no candidates\n";
            }
            if (!$verbose) update_option('apex_omega_commentor_last_tick_ts', time(), false);
            return;
        }

        // 1.8.7: تضمین برای هیت میلیونی با 0 کامنت — حتی اگر در cooldown باشد، وارد کن (سوتی ممنوع)
        // اگر پست 657 (یا مشابه 1M+) به خاطر cooldown 24h جا مانده و 0 کامنت دارد، آن را دستی اضافه کن
        if (!$verbose) {
            // فقط یکبار چک سبک برای هیت‌های جا مانده
            $mega_check = $wpdb->get_results($wpdb->prepare("SELECT p.ID, COALESCE(CAST(pm.meta_value AS UNSIGNED),0) as cur_views FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id=p.ID AND pm.meta_key='views' WHERE p.post_type='post' AND p.post_status='publish' AND CAST(pm.meta_value AS UNSIGNED) >= %d ORDER BY CAST(pm.meta_value AS UNSIGNED) DESC LIMIT 20", 500000), ARRAY_A);
            foreach ($mega_check as $mc) {
                $mid = (int)$mc['ID'];
                $mviews = (int)$mc['cur_views'];
                $mcur = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_post_ID=%d AND comment_approved='1'", $mid));
                if ($mcur === 0 && $mviews >= 800000) {
                    // آیا در $rows هست؟
                    $found=false; foreach($rows as $rr) if((int)$rr['ID']===$mid){$found=true;break;}
                    if(!$found){
                        // اگر به خاطر cooldown فیلتر شده، به زور اضافه کن (حتی اگر به تازگی کامنت خورده، چون 0 کامنت ضایع است)
                        $last_meta = get_post_meta($mid, self::META_LAST, true);
                        $in_cooldown = $last_meta && $last_meta >= $cooldown_cutoff;
                        if ($in_cooldown) {
                            error_log("[APEX Ω] Commentor: mega-hit $mid with $mviews views has 0 comments but in cooldown — forcing include");
                        }
                        $title = get_the_title($mid);
                        $rows[] = ['ID'=>$mid,'post_title'=>$title,'post_date_gmt'=>get_post_field('post_date_gmt',$mid),'cur_views'=>$mviews];
                    }
                }
            }
        }

        $exec = apex_omega_generate_uuid();
        $done_posts = 0;
        $done_comments = 0;
        $tick_start = microtime(true);
        foreach ($rows as $r) {
            // تایم‌اوت محافظ — هر تیک حداکثر 25 ثانیه تا 500 خطا ندهد
            if (microtime(true) - $tick_start > 25) {
                error_log("[APEX Ω] Commentor: tick timeout guard — processed $done_posts posts, breaking");
                break;
            }
            $pid = (int)$r['ID'];
            $cur_views = (int)$r['cur_views'];
            $title = $r['post_title'] ?: get_the_title($pid);
            // وزن خواننده — همون الگوی ریتم حرفه‌ای
            $weight = ArtistManager::get_weight_for_post($pid);
            // هدف کامنت بر اساس بازدید + وزن (همبسته)
            $stats = Adapter_KKSR::get_stats($pid);
            $avg = isset($stats['avg']) ? (float)$stats['avg'] : 4.0;
            $is_premium = \ApexOmega\Core\ArtistManager::is_premium_selected($pid);
            $target = self::calculate_target($cur_views, $weight, $avg, $is_premium, (int)$pid);
            // 2.1.0: برای پرطرفدار >100k خودکار بدون دخالت انسانی — هدف را 15% بیشتر کن
            if ($high_auto && $cur_views >= $high_thr) {
                $target = min($max_per_post, $target + max(1, (int)ceil($target * 0.15)));
            }
            // سقف کلی
            $target = min($target, $max_per_post);
            // تعداد فعلی کامنت‌های تأییدشده
            $current = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_post_ID=%d AND comment_approved='1'", $pid));
            if ($current >= $target) { if ($verbose) error_log("[APEX Ω] skip pid=$pid current=$current >= target=$target views=$cur_views weight=$weight avg=$avg"); continue; }
            // اگر قبلاً خیلی کامنت دارد (مثلاً دستی)، skip
            if ($current >= $max_per_post) { if ($verbose) error_log("[APEX Ω] skip pid=$pid at max_per_post $max_per_post"); continue; }

            // چند تا اضافه کنیم؟ — تازه 2-3 یکباره، پرطرفدار روزانه متناسب با بازدید (میلیونی بیشتر)
            // 1.8.7: سوتی ممنوع برای هیت‌ها — اگر بازدید میلیونی ولی کامنت صفر، پر کن تا خجالت نکشی
            $need = $target - $current;
            // 2.1.1: صفر را سریع پر کن — اولویت ویژه برای پست‌های بدون کامنت
            if ($current === 0) {
                if ($cur_views >= 500000) {
                    $need = min($need, mt_rand(min(8, $target), min(12, $target)));
                } elseif ($cur_views >= 100000) {
                    $need = min($need, mt_rand(min(5, $target), min(9, $target)));
                } elseif ($cur_views >= 10000) {
                    $need = min($need, mt_rand(min(4, $target), min(7, $target)));
                } else {
                    $hi = max(1, min(6, (int)$target));
                    $lo = min(4, $hi);
                    $need = min($need, mt_rand($lo, $hi));
                }
                if ($verbose) echo "zero-fill pid=$pid views=$cur_views target=$target need=$need\\n";
            } else {
                // (current !== 0 در این شاخه؛ پرکردن صفر در بالا هندل شده)
                if ($cur_views < $threshold) {
                    $need = min($need, mt_rand($s['min_comments'], $s['max_comments']));
                } else {
                    if ($cur_views >= 1000000) {
                        $daily_scaled = max($daily_growth + 2, 6);
                        $need = min($need, mt_rand(3, $daily_scaled));
                    } elseif ($cur_views >= 500000) {
                        $daily_scaled = max($daily_growth + 1, 5);
                        $need = min($need, mt_rand(2, $daily_scaled));
                    } elseif ($cur_views >= 100000) {
                        $daily_scaled = max($daily_growth, 3);
                        $need = min($need, mt_rand(1, $daily_scaled));
                    } else {
                        $need = min($need, mt_rand(1, $daily_growth));
                    }
                }
            }
            $need = max(1, min(14, $need));

            // اگر گفت‌وگو بسته باشد، باز کن — وگرنه کامنت تو دیتابیس هست ولی قالب نشان نمی‌دهد
            apex_omega_ensure_comments_open((int)$pid);
            // خواننده برای AI
            $artist_name = self::get_primary_artist($pid);
            if (!$artist_name) $artist_name = 'هنرمند ناشناس';

            $inserted = 0;
            for ($i=0; $i < $need; $i++) {
                // اطمینان از سقف
                if ($current + $inserted >= $target) break;
                if ($current + $inserted >= $max_per_post) break;
                $who = self::generate_name();
                // یکتا در کل تاریخچهٔ همین پست (نه فقط ۲۴ ساعت) — بدون چسباندن عدد
                $text = self::unique_text($pid, $artist_name, $title, $weight, $cur_views, $is_premium ?? false);
                if ($text === '') continue;
                // کمی تنوع زمانی: هر کامنت 2-10 دقیقه فاصله (برای طبیعی بودن تاریخ)
                // پخش زمانی طبیعی (نه ۱۰ کامنت در ۱۰ دقیقه)
                $comment_time_gmt = self::comment_time_gmt($pid, 72);
                $comment_time = get_date_from_gmt($comment_time_gmt, 'Y-m-d H:i:s');
                $cid = wp_insert_comment([
                    'comment_post_ID' => $pid,
                    'comment_author' => $who['author'],
                    'comment_author_email' => $who['email'],
                    'comment_author_url' => '',
                    'comment_content' => $text,
                    'comment_type' => '',
                    'comment_parent' => 0,
                    'user_id' => 0,
                    'comment_author_IP' => self::fake_ip(),
                    'comment_agent' => self::fake_agent(),
                    'comment_date' => $comment_time,
                    'comment_date_gmt' => $comment_time_gmt,
                    'comment_approved' => 1,
                ]);
                if ($cid && !is_wp_error($cid)) {
                    // متای کمکی برای تشخیص کامنت ربات (اختیاری)
                    add_comment_meta($cid, '_apex_commentor', 1, true);
                    add_comment_meta($cid, '_apex_weight', $weight, true);
                    // آپدیت شمارندهٔ کامنت پست (WP خودش می‌کند ولی برای اطمینان)
                    wp_update_comment_count($pid);
                    $inserted++;
                    // تاریخچه: هر کامنت یک لاگ جدا (خلاصه)
                    History::log($pid, 'comment', $current, $current+$inserted, 'commentor', 0, $exec, null, ['author'=>$who['author'],'weight'=>$weight,'target'=>$target]);
                }
                // فاصله کوتاه برای عدم اسپم
                usleep(50000);
            }
            if ($inserted > 0) {
                update_post_meta($pid, self::META_LAST, current_time('mysql', true));
                update_post_meta($pid, self::META_COUNT, (int)get_post_meta($pid, self::META_COUNT, true) + $inserted);
                $done_posts++;
                $done_comments += $inserted;
            }
            // برای اینکه هر تیک خیلی شلوغ نشه، اگر 3 پست پر کردیم و هنوز batch ادامه دارد، ادامه بده — ولی کل کامنت‌ها را لاگ کن
        }
        if ($done_posts > 0) {
            update_option('apex_omega_commentor_last_run', ['at'=>current_time('mysql', true),'posts'=>$done_posts,'comments'=>$done_comments,'exec'=>$exec], false);
            error_log("[APEX Ω] Commentor: {$done_comments} comments on {$done_posts} posts (threshold {$threshold})");
        }
        // 1.9.4 JOB-04: تیک همیشه بعد از اتمام موفق (حتی اگر 0 post جدید) — اگر خطای 500/503 نخوردیم، گیت 6ساعته ریست
        if (!$verbose) {
            // فقط اگر بدون exception تا اینجا آمدیم → موفق
            update_option('apex_omega_commentor_last_tick_ts', time(), false);
        }
    }

    public static function diag(): array {
        global $wpdb;
        $s = self::get_settings();
        $threshold = (int)$s['threshold'];
        $max_per_post = (int)$s['max_per_post'];
        $cooldown = (int)$s['cooldown_hours'] * HOUR_IN_SECONDS;
        $cooldown_cutoff = gmdate('Y-m-d H:i:s', time() - $cooldown);
        $total_posts = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='post' AND post_status='publish'");
        $with_comments = (int)$wpdb->get_var("SELECT COUNT(DISTINCT comment_post_ID) FROM {$wpdb->comments} WHERE comment_approved='1'");
        $zero = $total_posts - $with_comments;
        // Due count (same SQL as tick but without LIMIT)
        $recent_days = (int)$s['only_recent_days'];
        $where_recent = '';
        if ($recent_days > 0) {
            $cutoff = gmdate('Y-m-d H:i:s', time() - $recent_days * DAY_IN_SECONDS);
            $where_recent = $wpdb->prepare(" AND (p.post_date_gmt >= %s OR NOT EXISTS (SELECT 1 FROM {$wpdb->comments} c0 WHERE c0.comment_post_ID = p.ID AND c0.comment_approved='1')) ", $cutoff);
        }
        $sql = "
            SELECT p.ID, COALESCE(CAST(pm.meta_value AS UNSIGNED),0) as cur_views
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key='views'
            WHERE p.post_type='post' AND p.post_status='publish'
            {$where_recent}
            AND NOT EXISTS (
                SELECT 1 FROM {$wpdb->postmeta} pm2
                WHERE pm2.post_id = p.ID
                AND pm2.meta_key = %s
                AND pm2.meta_value >= %s
            )
        ";
        $candidates = $wpdb->get_results($wpdb->prepare($sql, self::META_LAST, $cooldown_cutoff), ARRAY_A);
        $due = count($candidates);
        // Sample 5 zero-comment posts with details
        $samples = [];
        $zero_rows = $wpdb->get_results("SELECT p.ID, p.post_title, p.post_date_gmt, COALESCE(CAST(pm.meta_value AS UNSIGNED),0) as cur_views FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id=p.ID AND pm.meta_key='views' WHERE p.post_type='post' AND p.post_status='publish' AND NOT EXISTS (SELECT 1 FROM {$wpdb->comments} c WHERE c.comment_post_ID=p.ID AND c.comment_approved='1') ORDER BY p.post_date_gmt DESC LIMIT 5", ARRAY_A);
        foreach ($zero_rows as $r) {
            $pid=(int)$r['ID'];
            $weight = \ApexOmega\Core\ArtistManager::get_weight_for_post($pid);
            $stats = \ApexOmega\Core\Adapter_KKSR::get_stats($pid);
            $avg = isset($stats['avg']) ? (float)$stats['avg'] : 4.0;
            $is_premium = \ApexOmega\Core\ArtistManager::is_premium_selected((int)$r['ID']);
            $target = self::calculate_target((int)$r['cur_views'], $weight, $avg, $is_premium, (int)$pid);
            $current = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_post_ID=%d AND comment_approved='1'", $pid));
            $samples[] = ['ID'=>$pid,'title'=>mb_strimwidth($r['post_title']??'',0,40,'…'),'views'=>(int)$r['cur_views'],'weight'=>$weight,'avg'=>$avg,'target'=>$target,'current'=>$current];
        }
        $last_run = get_option('apex_omega_commentor_last_run', []);
        $last_tick = (int)get_option('apex_omega_commentor_last_tick_ts', 0);
        return ['total_posts'=>$total_posts,'with_comments'=>$with_comments,'zero'=>$zero,'due'=>$due,'candidates_sample'=>count($candidates),'samples'=>$samples,'settings'=>$s,'last_run'=>$last_run,'last_tick'=> $last_tick ? gmdate('Y-m-d H:i:s',$last_tick).' ('.(time()-$last_tick).'s ago)' : 'never','cooldown_cutoff'=>$cooldown_cutoff];
    }

    public static function send_for_post(int $post_id, int $requested_count): array {
        if (!get_post($post_id)) return ['success'=>false,'message'=>'نوشته یافت نشد.'];
        $requested_count = max(1, min(500, $requested_count)); // 2.0 hourly: raised 60→500, final clamp by max_per_post below
        $settings = self::get_settings();
        $max_per_post = (int)$settings['max_per_post'];
        // Check current count
        global $wpdb;
        $current = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_post_ID=%d AND comment_approved='1'", $post_id));
        $remaining = $max_per_post - $current;
        if ($remaining <= 0) return ['success'=>false,'message'=>"این پست به سقف $max_per_post کامنت رسیده."];
        $count = min($requested_count, $remaining);
        // Also respect target but allow manual to exceed target up to max_per_post
        $title = get_the_title($post_id) ?: '';
        $weight = \ApexOmega\Core\ArtistManager::get_weight_for_post($post_id);
        $cur_views = (int) get_post_meta($post_id, 'views', true);
        $stats = \ApexOmega\Core\Adapter_KKSR::get_stats($post_id);
        $avg = isset($stats['avg']) ? (float)$stats['avg'] : 4.0;
        $artist_name = self::get_primary_artist($post_id);
        if (!$artist_name) $artist_name = 'هنرمند ناشناس';
        $is_premium = \ApexOmega\Core\ArtistManager::is_premium_selected($post_id);
        // باز کردن کامنت بدون تغییر post_modified (جلوگیری از churn سایتمپ)
        apex_omega_ensure_comments_open((int)$post_id);
        $exec = apex_omega_generate_uuid();
        $inserted = 0;
        for ($i=0; $i < $count; $i++) {
            $who = self::generate_name();
            // پرمیوم هم پاس داده شود (قبلاً فراموش شده بود)
            $text = self::unique_text($post_id, $artist_name, $title, $weight, $cur_views, $is_premium);
            if ($text === '') continue;
            $comment_time_gmt = self::comment_time_gmt($post_id, 36);
            $comment_time = get_date_from_gmt($comment_time_gmt, 'Y-m-d H:i:s');
            $cid = wp_insert_comment([
                'comment_post_ID' => $post_id,
                'comment_author' => $who['author'],
                'comment_author_email' => $who['email'],
                'comment_author_url' => '',
                'comment_content' => $text,
                'comment_type' => '',
                'comment_parent' => 0,
                'user_id' => 0,
                'comment_author_IP' => self::fake_ip(),
                'comment_agent' => self::fake_agent(),
                'comment_date' => $comment_time,
                'comment_date_gmt' => $comment_time_gmt,
                'comment_approved' => 1,
            ]);
            if ($cid && !is_wp_error($cid)) {
                add_comment_meta($cid, '_apex_commentor', 1, true);
                add_comment_meta($cid, '_apex_weight', $weight, true);
                wp_update_comment_count($post_id);
                $inserted++;
                \ApexOmega\Core\History::log($post_id, 'comment', $current, $current+$inserted, 'manual_comment', get_current_user_id(), $exec, null, ['author'=>$who['author'],'weight'=>$weight,'requested'=>$requested_count]);
            }
            usleep(30000);
        }
        if ($inserted > 0) {
            update_post_meta($post_id, self::META_LAST, current_time('mysql', true));
            update_post_meta($post_id, self::META_COUNT, (int)get_post_meta($post_id, self::META_COUNT, true) + $inserted);
            update_option('apex_omega_commentor_last_run', ['at'=>current_time('mysql', true),'posts'=>1,'comments'=>$inserted,'exec'=>$exec], false);
        }
        return ['success'=>true,'inserted'=>$inserted,'requested'=>$requested_count,'current'=>$current+$inserted,'max'=>$max_per_post];
    }

    /**
     * 💬 Bulk برای آثار منتخب — مثل بازدید، ولی برای کامنت
     * $mode: 'add' = افزودن N جدید (پیش‌فرض، مثل بازدید بازه), 'set' = رساندن به حداقل N
     * $count_min/$count_max: بازه تصادفی هر پست (اگر max=0 یا خالی → همان min)
     */
    public static function bulk_apply_to_ids(array $post_ids, int $count_min = 5, int $count_max = 0, array $options = []): array {
        if (empty($post_ids)) return ['success'=>false,'message'=>'هیچ پستی انتخاب نشده'];
        $count_min = max(1, min(500, $count_min));
        if ($count_max) $count_max = max($count_min, min(500, $count_max));
        else $count_max = $count_min;
        $mode = $options['mode'] ?? 'add'; // add|set
        $only_zero = !empty($options['only_zero']);
        $is_premium_opt = $options['is_premium'] ?? null; // null=auto by is_premium_selected
        $settings = self::get_settings();
        $max_per_post = (int)$settings['max_per_post'];
        global $wpdb;
        $exec = apex_omega_generate_uuid();
        $user_id = get_current_user_id();
        $total = count($post_ids);
        $applied_posts = 0;
        $applied_comments = 0;
        $skipped = 0;
        $errors = [];
        $details = [];
        // برای توزیع آماری
        $buckets = ['0'=>0,'1-5'=>0,'6-15'=>0,'16-30'=>0,'30+'=>0];
        $before_total = 0;
        // اول آمار قبل
        foreach ($post_ids as $pid) {
            if (!$pid || !get_post($pid)) { $skipped++; continue; }
            $cur = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_post_ID=%d AND comment_approved='1'", $pid));
            $before_total += $cur;
            // bucket before
            if ($cur === 0) $buckets['0']++;
            elseif ($cur <= 5) $buckets['1-5']++;
            elseif ($cur <= 15) $buckets['6-15']++;
            elseif ($cur <= 30) $buckets['16-30']++;
            else $buckets['30+']++;
        }
        // پردازش هر پست
        foreach ($post_ids as $pid) {
            $pid = (int)$pid;
            if (!$pid || !get_post($pid)) continue;
            // فیلتر only_zero
            $cur = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_post_ID=%d AND comment_approved='1'", $pid));
            if ($only_zero && $cur > 0) { $skipped++; continue; }
            if ($cur >= $max_per_post) { $skipped++; continue; }
            $remaining = $max_per_post - $cur;
            // چند تا برای این پست؟
            $need = mt_rand($count_min, $count_max);
            if ($mode === 'set') {
                // رساندن به حداقل N: اگر الان 3 تا دارد و N=10 می‌خواهد → 7 تا اضافه
                if ($cur >= $need) { $skipped++; continue; }
                $need = $need - $cur;
            }
            $need = min($need, $remaining, 500);
            if ($need <= 0) { $skipped++; continue; }
            $title = get_the_title($pid) ?: '';
            $weight = \ApexOmega\Core\ArtistManager::get_weight_for_post($pid);
            $cur_views = (int) get_post_meta($pid, 'views', true);
            $stats = \ApexOmega\Core\Adapter_KKSR::get_stats($pid);
            $avg = isset($stats['avg']) ? (float)$stats['avg'] : 4.0;
            $artist_name = self::get_primary_artist($pid);
            if (!$artist_name) $artist_name = 'هنرمند ناشناس';
            $is_premium = $is_premium_opt !== null ? (bool)$is_premium_opt : \ApexOmega\Core\ArtistManager::is_premium_selected($pid);
            // comment_status باز (بدون تغییر post_modified)
            apex_omega_ensure_comments_open((int)$pid);
            $inserted = 0;
            for ($i=0; $i < $need; $i++) {
                if ($cur + $inserted >= $max_per_post) break;
                $who = self::generate_name();
                $text = self::unique_text($pid, $artist_name, $title, $weight, $cur_views, $is_premium);
                if ($text === '') continue;
                $comment_time_gmt = self::comment_time_gmt($pid, 72);
                $comment_time = get_date_from_gmt($comment_time_gmt, 'Y-m-d H:i:s');
                $cid = wp_insert_comment([
                    'comment_post_ID' => $pid,
                    'comment_author' => $who['author'],
                    'comment_author_email' => $who['email'],
                    'comment_author_url' => '',
                    'comment_content' => $text,
                    'comment_type' => '',
                    'comment_parent' => 0,
                    'user_id' => 0,
                    'comment_author_IP' => self::fake_ip(),
                    'comment_agent' => self::fake_agent(),
                    'comment_date' => $comment_time,
                    'comment_date_gmt' => $comment_time_gmt,
                    'comment_approved' => 1,
                ]);
                if ($cid && !is_wp_error($cid)) {
                    add_comment_meta($cid, '_apex_commentor', 1, true);
                    add_comment_meta($cid, '_apex_weight', $weight, true);
                    wp_update_comment_count($pid);
                    $inserted++;
                    \ApexOmega\Core\History::log($pid, 'comment', $cur, $cur + $inserted, 'bulk_comment_selected', $user_id, $exec, null, ['author'=>$who['author'],'weight'=>$weight,'requested'=>$need,'is_premium'=>$is_premium]);
                }
                usleep(20000);
            }
            if ($inserted > 0) {
                update_post_meta($pid, self::META_LAST, current_time('mysql', true));
                update_post_meta($pid, self::META_COUNT, (int)get_post_meta($pid, self::META_COUNT, true) + $inserted);
                $applied_posts++;
                $applied_comments += $inserted;
                $details[] = ['post_id'=>$pid,'before'=>$cur,'added'=>$inserted,'after'=>$cur+$inserted];
            } else {
                $skipped++;
            }
        }
        if ($applied_comments > 0) {
            update_option('apex_omega_commentor_last_run', ['at'=>current_time('mysql', true),'posts'=>$applied_posts,'comments'=>$applied_comments,'exec'=>$exec,'bulk_selected'=>true], false);
        }
        // آمار بعد
        $after_total = 0;
        $after_buckets = ['0'=>0,'1-5'=>0,'6-15'=>0,'16-30'=>0,'30+'=>0];
        foreach ($post_ids as $pid) {
            $cur = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_post_ID=%d AND comment_approved='1'", $pid));
            $after_total += $cur;
            if ($cur === 0) $after_buckets['0']++;
            elseif ($cur <= 5) $after_buckets['1-5']++;
            elseif ($cur <= 15) $after_buckets['6-15']++;
            elseif ($cur <= 30) $after_buckets['16-30']++;
            else $after_buckets['30+']++;
        }
        $pct_posts = $total ? round($applied_posts / $total * 100, 1) : 0;
        $avg_before = $total ? round($before_total / $total, 1) : 0;
        $avg_after = $total ? round($after_total / $total, 1) : 0;
        return [
            'success'=>true,
            'total'=>$total,
            'applied_posts'=>$applied_posts,
            'applied_comments'=>$applied_comments,
            'skipped'=>$skipped,
            'percent'=>$pct_posts,
            'avg_before'=>$avg_before,
            'avg_after'=>$avg_after,
            'before_total'=>$before_total,
            'after_total'=>$after_total,
            'buckets_before'=>$buckets,
            'buckets_after'=>$after_buckets,
            'execution_id'=>$exec,
            'errors'=>$errors,
            'details'=>$details,
            'message'=> $applied_comments ? "✅ {$applied_comments} کامنت به {$applied_posts} از {$total} آهنگ ({$pct_posts}٪) اضافه شد — میانگین {$avg_before} → {$avg_after}" : 'هیچ کامنتی اضافه نشد (همه به سقف رسیده یا فیلتر شدند)',
        ];
    }

    // استخراج نام خواننده از عنوان وقتی ترم taxonomy ثبت نشده: «... از پازل بند» / «- پازل بند» / نام شناخته‌شده
    private static function artist_from_title(string $title): string {
        $t = trim(preg_replace('/\s*[\(\[][^\)\]]*[\)\]]\s*/u', ' ', (string)$title));
        if ($t === '') return '';
        // ۱) نام هنرمند شناخته‌شده داخل عنوان (بلندترین تطبیق برنده است: «محسن یگانه» بر «یگانه»)
        $best = '';
        foreach (self::known_artist_names() as $kn) {
            $kn = trim((string)$kn);
            if (mb_strlen($kn) < 3) continue;
            if (mb_stripos($t, $kn) !== false && mb_strlen($kn) > mb_strlen($best)) $best = $kn;
        }
        if ($best !== '') return $best;
        // ۲) الگوی «از X» / «با صدای X» / «اثر X» در انتهای عنوان
        if (preg_match('/(?:از|با\s*صدای|اثر|به\s*خوانندگی|به\s*همراهی)\s+([\p{L}\p{M}][\p{L}\p{M}\s\x{200C}]{1,38})\s*$/u', $t, $m)) {
            $cand = trim(preg_replace('/\s*(?:با\s*کیفیت|کیفیت|mp3|320|128|192|256).*$/iu', '', $m[1]));
            $cand = self::trim_sep($cand);
            if (mb_strlen($cand) >= 3 && !self::artist_is_placeholder($cand)) return $cand;
        }
        // ۳) جداکنندهٔ رایج «آهنگ - خواننده»
        $ext = ArtistManager::extract_artist_from_title($t);
        return ($ext && !self::artist_is_placeholder($ext)) ? $ext : '';
    }

    public static function get_primary_artist(int $post_id): string {
        $tax = ArtistManager::detect_artist_taxonomy();
        if ($tax) {
            $terms = wp_get_post_terms($post_id, $tax, ['fields'=>'names']);
            if (!empty($terms) && !is_wp_error($terms) && !self::artist_is_placeholder((string)$terms[0])) return $terms[0];
        }
        return self::artist_from_title((string) get_the_title($post_id));
    }

    // زمان طبیعی کامنت: پخش‌شده در چند ساعت/روز گذشته، هرگز قبل از انتشار پست و هرگز در آینده
    public static function comment_time_gmt(int $post_id, int $window_hours = 72): string {
        $now = time();
        $window = max(HOUR_IN_SECONDS, (int)$window_hours * HOUR_IN_SECONDS);
        $ts = $now - mt_rand(60, $window);
        if ($post_id) {
            $pub = (string) get_post_field('post_date_gmt', $post_id);
            if ($pub) {
                $pub_ts = strtotime($pub . ' GMT');
                if ($pub_ts && $pub_ts > $ts) $ts = $pub_ts + mt_rand(MINUTE_IN_SECONDS, 6 * HOUR_IN_SECONDS);
            }
        }
        if ($ts > $now - 60) $ts = $now - mt_rand(60, 1800);
        return gmdate('Y-m-d H:i:s', $ts);
    }

    private static function fake_ip(): string {
        return mt_rand(1,223).'.'.mt_rand(0,255).'.'.mt_rand(0,255).'.'.mt_rand(1,254);
    }

    // User-Agent متنوع مثل کاربر واقعی (نه همه «Mozilla/5.0»)
    public static function fake_agent(): string {
        $pool = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',
            'Mozilla/5.0 (Linux; Android 14; SM-A536B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Mobile Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0',
        ];
        return $pool[array_rand($pool)];
    }
}
