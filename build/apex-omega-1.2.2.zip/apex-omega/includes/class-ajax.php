<?php
namespace ApexOmega\Core;

if (!defined('ABSPATH')) exit;

class Ajax {
    public static function init(): void {
        $actions = [
            'apex_save_manual',
            'apex_preview_schedule',
            'apex_create_schedule',
            'apex_pause_schedule',
            'apex_resume_schedule',
            'apex_cancel_schedule',
            'apex_rollback',
            'apex_bulk_apply',
            'apex_preview_tier',
            'apex_apply_tier',
            'apex_undo_tier',
            'apex_ai_suggest',
            'apex_ai_save',
            'apex_test_ai',
            'apex_save_artist_weights',
            'apex_save_artist_taxonomy',
            'apex_auto_artist_ai',
            'apex_auto_artist_ir',
            'apex_export_artist_csv',
            'apex_export_history_csv',
            'apex_export_tiers_json',
            'apex_import_artist_csv',
            'apex_import_tiers_json',
            'apex_save_evergreen',
            'apex_save_rhythm',
            'apex_save_autowatch',
            'apex_dismiss_notice',
        ];
        foreach ($actions as $a) {
            add_action('wp_ajax_' . $a, [__CLASS__, 'router']);
        }
    }

    public static function router(): void {
        $action = str_replace('wp_ajax_', '', current_action());
        // بررسی دسترسی
        if (!apex_omega_user_can_manage()) {
            wp_send_json_error(['message' => 'دسترسی غیرمجاز.'], 403);
        }
        // نانس
        $nonce = $_REQUEST['_ajax_nonce'] ?? $_REQUEST['nonce'] ?? '';
        if (!wp_verify_nonce($nonce, 'apex_omega_nonce')) {
            wp_send_json_error(['message' => 'نشانه امنیتی نامعتبر (nonce).'], 403);
        }

        switch ($action) {
            case 'apex_save_manual':
                self::save_manual();
                break;
            case 'apex_preview_schedule':
                self::preview_schedule();
                break;
            case 'apex_create_schedule':
                self::create_schedule();
                break;
            case 'apex_pause_schedule':
                self::pause_schedule();
                break;
            case 'apex_resume_schedule':
                self::resume_schedule();
                break;
            case 'apex_cancel_schedule':
                self::cancel_schedule();
                break;
            case 'apex_rollback':
                self::rollback();
                break;
            case 'apex_bulk_apply':
                self::bulk_apply();
                break;
            case 'apex_preview_tier':
                self::preview_tier();
                break;
            case 'apex_apply_tier':
                self::apply_tier();
                break;
            case 'apex_ai_suggest':
                self::ai_suggest();
                break;
            case 'apex_ai_save':
                self::ai_save();
                break;
            case 'apex_save_artist_weights':
                self::save_artist_weights();
                break;
            case 'apex_auto_artist_ai':
                self::auto_artist_ai();
                break;
            case 'apex_auto_artist_ir':
                self::auto_artist_ir();
                break;
            case 'apex_test_ai':
                self::test_ai();
                break;
            case 'apex_save_artist_taxonomy':
                self::save_artist_taxonomy();
                break;
            case 'apex_undo_tier':
                self::undo_tier();
                break;
            case 'apex_export_artist_csv':
                self::export_artist_csv();
                break;
            case 'apex_export_history_csv':
                self::export_history_csv();
                break;
            case 'apex_export_tiers_json':
                self::export_tiers_json();
                break;
            case 'apex_import_artist_csv':
                self::import_artist_csv();
                break;
            case 'apex_import_tiers_json':
                self::import_tiers_json();
                break;
            case 'apex_save_evergreen':
                self::save_evergreen();
                break;
            case 'apex_save_rhythm':
                self::save_rhythm();
                break;
            case 'apex_save_autowatch':
                self::save_autowatch();
                break;
            default:
                wp_send_json_error(['message' => 'اکشن نامعتبر'], 400);
        }
    }

    private static function save_manual(): void {
        $post_id = isset($_POST['post_id']) ? (int) $_POST['post_id'] : 0;
        if (!$post_id || !get_post($post_id)) wp_send_json_error(['message'=>'نوشته نامعتبر'], 400);
        if (!current_user_can('edit_post', $post_id) && !apex_omega_user_can_manage()) wp_send_json_error(['message'=>'دسترسی ویرایش نوشته ندارید'], 403);

        // قفل
        $lock_key = "apex_manual_{$post_id}";
        if (!Database::acquire_lock($lock_key, 30)) {
            wp_send_json_error(['message'=>'عملیات دیگری در حال اجراست.'], 409);
        }

        $mode = isset($_POST['mode']) ? sanitize_text_field($_POST['mode']) : 'manual';
        $views = $_POST['views'] ?? null;
        $casts = $_POST['casts'] ?? null;
        $avg = $_POST['avg'] ?? null;
        $exec = apex_omega_generate_uuid();

        $results = [];
        $has_error = false;

        // بازدید
        if ($views !== null && $views !== '') {
            [$ok, $errs, $v] = Validator::validate_views($views);
            if (!$ok) {
                $results['views'] = ['success'=>false, 'errors'=>$errs];
                $has_error = true;
            } else {
                $old = Adapter_Views::get_views($post_id);
                // بررسی نوسان بدون تأیید؟
                $vol = Validator::check_volatility($old, $v, null, null);
                if ($vol['requires_confirm'] && empty($_POST['confirm_volatility'])) {
                    $results['views'] = ['success'=>false, 'requires_confirm'=>true, 'warnings'=>$vol['warnings'], 'message'=>'تغییر بازدید نیاز به تأیید دارد.'];
                    $has_error = true;
                } else {
                    $success = Adapter_Views::set_views($post_id, $v, 'manual', $exec);
                    if ($success) {
                        History::log($post_id, 'views', $old, $v, 'manual', get_current_user_id(), $exec);
                        $results['views'] = ['success'=>true, 'old'=>$old, 'new'=>$v];
                    } else {
                        $results['views'] = ['success'=>false, 'message'=>'خطا در ذخیره بازدید'];
                        $has_error = true;
                    }
                }
            }
        }

        // kk casts + avg
        if ($casts !== null && $casts !== '' || $avg !== null && $avg !== '') {
            $detect = Adapter_KKSR::detect();
            $best = $detect['best'];
            $stats = Adapter_KKSR::get_stats($post_id);

            $new_casts = $stats['casts'];
            $new_avg = $stats['avg'];

            if ($casts !== null && $casts !== '') {
                [$ok, $errs, $vc] = Validator::validate_casts($casts);
                if (!$ok) {
                    $results['casts'] = ['success'=>false, 'errors'=>$errs];
                    $has_error = true;
                } else {
                    $new_casts = $vc;
                }
            }
            if ($avg !== null && $avg !== '') {
                [$ok, $errs, $va] = Validator::validate_avg($avg, $best);
                if (!$ok) {
                    $results['avg'] = ['success'=>false, 'errors'=>$errs];
                    $has_error = true;
                } else {
                    $new_avg = $va;
                }
            }

            if (!$has_error || (!isset($results['casts']['success']) || $results['casts']['success']!==false) && (!isset($results['avg']['success']) || $results['avg']['success']!==false)) {
                // سازگاری
                $new_ratings = $new_avg * $new_casts / $best * 5;
                $cons_errors = Adapter_KKSR::validate_consistency($new_casts, $new_ratings, $new_avg, $best);
                if (!empty($cons_errors)) {
                    // هشدار اما اجازه ذخیره با تأیید
                    if (empty($_POST['confirm_inconsistency'])) {
                        $results['kksr'] = ['success'=>false, 'requires_confirm'=>true, 'warnings'=>$cons_errors, 'message'=>'ناسازگاری در داده‌های امتیاز؛ تأیید کنید.'];
                        $has_error = true;
                    }
                }
                if (!$has_error || !empty($_POST['confirm_inconsistency'])) {
                    $old_combined = ['casts'=>$stats['casts'],'ratings'=>$stats['ratings'],'avg'=>$stats['avg']];
                    $success = Adapter_KKSR::set_stats($post_id, $new_casts, $new_ratings, $new_avg, 'manual', $exec);
                    if ($success) {
                        History::log($post_id, 'kksr_combined', wp_json_encode($old_combined, JSON_UNESCAPED_UNICODE), wp_json_encode(['casts'=>$new_casts,'ratings'=>$new_ratings,'avg'=>$new_avg], JSON_UNESCAPED_UNICODE), 'manual', get_current_user_id(), $exec, null, ['best'=>$best]);
                        $results['kksr'] = ['success'=>true, 'old'=>$old_combined, 'new'=>['casts'=>$new_casts,'avg'=>$new_avg]];
                    } else {
                        $results['kksr'] = ['success'=>false, 'message'=>'خطا در ذخیره آمار امتیاز'];
                        $has_error = true;
                    }
                }
            }
        }

        update_post_meta($post_id, '_apex_mode', $mode);
        Database::release_lock($lock_key);

        if ($has_error && !isset($results['views']['success']) && !isset($results['kksr']['success'])) {
            // اگر هیچ موفقیتی نبود
            // اما اگر بخشی موفق بود، همچنان success کلی بفرست با جزئیات
        }

        wp_send_json_success(['results'=>$results, 'execution_id'=>$exec]);
    }

    private static function preview_schedule(): void {
        $post_id = (int) ($_POST['post_id'] ?? 0);
        $field = sanitize_text_field($_POST['field_type'] ?? '');
        $target = $_POST['target_value'] ?? null;
        $start_gmt = sanitize_text_field($_POST['start_at_gmt'] ?? '');
        $end_gmt = sanitize_text_field($_POST['end_at_gmt'] ?? '');
        $interval = (int) ($_POST['interval_seconds'] ?? 3600);

        if (!$post_id || !$field || $target===null) wp_send_json_error(['message'=>'پارامتر ناقص'],400);
        $preview = Scheduler::preview($post_id, $field, $target, $start_gmt, $end_gmt, $interval);
        wp_send_json_success($preview);
    }

    private static function create_schedule(): void {
        $data = [
            'post_id' => (int) ($_POST['post_id'] ?? 0),
            'field_type' => sanitize_text_field($_POST['field_type'] ?? ''),
            'target_value' => $_POST['target_value'] ?? null,
            'interval_seconds' => (int) ($_POST['interval_seconds'] ?? 3600),
            'start_at_gmt' => sanitize_text_field($_POST['start_at_gmt'] ?? ''),
            'end_at_gmt' => sanitize_text_field($_POST['end_at_gmt'] ?? ''),
            'start_at' => isset($_POST['start_at_gmt']) ? get_date_from_gmt(sanitize_text_field($_POST['start_at_gmt']), 'Y-m-d H:i:s') : null,
            'end_at' => isset($_POST['end_at_gmt']) ? get_date_from_gmt(sanitize_text_field($_POST['end_at_gmt']), 'Y-m-d H:i:s') : null,
            'min_allowed' => (isset($_POST['min_allowed']) && $_POST['min_allowed'] !== '' && (int)$_POST['min_allowed'] > 0) ? $_POST['min_allowed'] : null,
            'max_allowed' => (isset($_POST['max_allowed']) && $_POST['max_allowed'] !== '' && (int)$_POST['max_allowed'] > 0) ? $_POST['max_allowed'] : null,
            'max_step' => (isset($_POST['max_step']) && $_POST['max_step'] !== '' && (int)$_POST['max_step'] > 0) ? $_POST['max_step'] : null,
            'max_percent_step' => (isset($_POST['max_percent_step']) && $_POST['max_percent_step'] !== '' && (float)$_POST['max_percent_step'] > 0) ? $_POST['max_percent_step'] : null,
            'require_confirm_large_drop' => !empty($_POST['require_confirm_large_drop']),
            'confirm_large_drop' => !empty($_POST['confirm_large_drop']),
            'confirm_volatility' => !empty($_POST['confirm_volatility']),
            'mode' => 'scheduled',
        ];
        if (isset($_POST['kksr_avg_target'])) $data['kksr_avg_target'] = $_POST['kksr_avg_target'];
        if (isset($_POST['kksr_casts_target'])) $data['kksr_casts_target'] = $_POST['kksr_casts_target'];

        $res = Scheduler::create_schedule($data);
        if (empty($res['success'])) {
            wp_send_json_error($res, 400);
        }
        wp_send_json_success($res);
    }

    private static function pause_schedule(): void {
        $id = (int) ($_POST['schedule_id'] ?? 0);
        if (!$id) wp_send_json_error(['message'=>'شناسه نامعتبر'],400);
        $ok = Scheduler::pause($id);
        if ($ok) wp_send_json_success(['message'=>'برنامه متوقف شد.']);
        wp_send_json_error(['message'=>'خطا در توقف'],500);
    }
    private static function resume_schedule(): void {
        $id = (int) ($_POST['schedule_id'] ?? 0);
        if (!$id) wp_send_json_error(['message'=>'شناسه نامعتبر'],400);
        $ok = Scheduler::resume($id);
        if ($ok) wp_send_json_success(['message'=>'برنامه ادامه یافت.']);
        wp_send_json_error(['message'=>'خطا'],500);
    }
    private static function cancel_schedule(): void {
        $id = (int) ($_POST['schedule_id'] ?? 0);
        if (!$id) wp_send_json_error(['message'=>'شناسه نامعتبر'],400);
        $ok = Scheduler::cancel($id);
        if ($ok) wp_send_json_success(['message'=>'برنامه لغو شد.']);
        wp_send_json_error(['message'=>'خطا'],500);
    }

    private static function rollback(): void {
        $history_id = (int) ($_POST['history_id'] ?? 0);
        if (!$history_id) wp_send_json_error(['message'=>'شناسه تاریخچه نامعتبر'],400);
        $res = History::rollback($history_id);
        if ($res['success']) wp_send_json_success($res);
        wp_send_json_error($res, 400);
    }

    private static function bulk_apply(): void {
        $post_ids = $_POST['post_ids'] ?? [];
        if (is_string($post_ids)) $post_ids = explode(',', $post_ids);
        $post_ids = array_map('intval', (array)$post_ids);
        $post_ids = array_filter($post_ids);
        if (empty($post_ids)) wp_send_json_error(['message'=>'هیچ نوشته‌ای انتخاب نشده'],400);

        $field = sanitize_text_field($_POST['field_type'] ?? '');
        $value = $_POST['value'] ?? null;
        $mode = sanitize_text_field($_POST['mode'] ?? 'manual');

        $exec = apex_omega_generate_uuid();
        $success_count = 0;
        $errors = [];

        foreach ($post_ids as $pid) {
            if (!get_post($pid)) { $errors[] = "نوشته $pid یافت نشد."; continue; }
            if (!current_user_can('edit_post', $pid) && !apex_omega_user_can_manage()) { $errors[] = "دسترسی ویرایش پست $pid ندارید."; continue; }
            if ($field === 'views') {
                [$ok, $errs, $v] = Validator::validate_views($value);
                if (!$ok) { $errors[] = "پست $pid: " . implode(' ', $errs); continue; }
                $old = Adapter_Views::get_views($pid);
                if (Adapter_Views::set_views($pid, $v, 'bulk_manual', $exec)) {
                    History::log($pid, 'views', $old, $v, 'bulk_manual', get_current_user_id(), $exec);
                    update_post_meta($pid, '_apex_mode', $mode);
                    $success_count++;
                }
            } elseif (in_array($field, ['kksr_casts','kksr_avg'], true)) {
                $detect = Adapter_KKSR::detect();
                $best = $detect['best'];
                $stats = Adapter_KKSR::get_stats($pid);
                if ($field === 'kksr_casts') {
                    [$ok, $errs, $vc] = Validator::validate_casts($value);
                    if (!$ok) { $errors[] = "پست $pid: " . implode(' ', $errs); continue; }
                    $old = $stats;
                    $new_ratings = $stats['avg'] * $vc / $best *5;
                    if (Adapter_KKSR::set_stats($pid, $vc, $new_ratings, $stats['avg'], 'bulk_manual', $exec)) {
                        History::log($pid, 'kksr_casts', $stats['casts'], $vc, 'bulk_manual', get_current_user_id(), $exec);
                        $success_count++;
                    }
                } else {
                    [$ok, $errs, $va] = Validator::validate_avg($value, $best);
                    if (!$ok) { $errors[] = "پست $pid: " . implode(' ', $errs); continue; }
                    $new_ratings = $va * $stats['casts'] / $best *5;
                    if (Adapter_KKSR::set_stats($pid, $stats['casts'], $new_ratings, $va, 'bulk_manual', $exec)) {
                        History::log($pid, 'kksr_avg', $stats['avg'], $va, 'bulk_manual', get_current_user_id(), $exec);
                        $success_count++;
                    }
                }
                update_post_meta($pid, '_apex_mode', $mode);
            } else {
                $errors[] = "فیلد $field پشتیبانی نمی‌شود در حالت گروهی.";
            }
        }

        wp_send_json_success(['success_count'=>$success_count, 'errors'=>$errors, 'execution_id'=>$exec]);
    }

    private static function preview_tier(): void {
        $counts = $_POST['counts'] ?? [];
        if (is_string($counts)) $counts = json_decode(stripslashes($counts), true) ?: [];
        // ممکن است به صورت counts[tier_1]=5 بیاید
        if (empty($counts) && isset($_POST['counts'])) {
            // حالت fallback: $_POST['counts'] آرایه PHP است
            $counts = (array) $_POST['counts'];
        }
        // sanitize
        $clean = [];
        foreach ((array)$counts as $k=>$v) {
            $k = sanitize_text_field($k);
            $clean[$k] = max(0, (int)$v);
        }
        $filters = [
            'category' => sanitize_text_field($_POST['category'] ?? 'all'),
            'post_type' => sanitize_text_field($_POST['post_type'] ?? 'any'),
            'artist_aware' => !empty($_POST['artist_aware']),
        ];
        $res = \ApexOmega\Core\TierManager::preview_distribution($clean, $filters);
        if (empty($res['success'])) wp_send_json_error($res, 400);
        wp_send_json_success($res);
    }

    private static function apply_tier(): void {
        $counts = $_POST['counts'] ?? [];
        if (is_string($counts)) $counts = json_decode(stripslashes($counts), true) ?: [];
        $clean = [];
        foreach ((array)$counts as $k=>$v) {
            $k = sanitize_text_field($k);
            $clean[$k] = max(0, (int)$v);
        }
        $filters = [
            'category' => sanitize_text_field($_POST['category'] ?? 'all'),
            'post_type' => sanitize_text_field($_POST['post_type'] ?? 'any'),
            'artist_aware' => !empty($_POST['artist_aware']),
        ];
        // ذخیره حالت خودکار
        $auto_enable = !empty($_POST['auto_enable']);
        if ($auto_enable) {
            update_option('apex_omega_auto_tier', ['enabled'=>true, 'counts'=>$clean, 'filters'=>$filters, 'updated_at'=>current_time('mysql', true)], false);
            \ApexOmega\Core\TierManager::schedule_auto();
        } else {
            // اگر تیک برداشته شد
            $auto = get_option('apex_omega_auto_tier', []);
            if (!empty($auto['enabled'])) {
                update_option('apex_omega_auto_tier', ['enabled'=>false], false);
                \ApexOmega\Core\TierManager::unschedule_auto();
            }
        }
        $res = \ApexOmega\Core\TierManager::apply_distribution($clean, $filters);
        if (empty($res['success'])) wp_send_json_error($res, 400);
        wp_send_json_success($res);
    }

    private static function ai_suggest(): void {
        global $wpdb;
        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='post' AND post_status='publish'");
        $tiers = \ApexOmega\Core\TierManager::get_tiers();
        $res = \ApexOmega\Core\AI_Helper::suggest_distribution($total, $tiers);
        if (!empty($res['success'])) wp_send_json_success($res);
        wp_send_json_error($res, 400);
    }

    private static function ai_save(): void {
        $data = [
            'api_key' => $_POST['api_key'] ?? '',
            'model' => $_POST['model'] ?? 'gpt-4o-mini',
            'endpoint' => $_POST['endpoint'] ?? 'https://api.gapgpt.app/v1/chat/completions',
            'provider' => 'gapgpt',
        ];
        // اگر کاربر •••• فرستاد، نگه دار
        if ($data['api_key'] === '••••••••' || $data['api_key'] === '') {
            $cur = \ApexOmega\Core\AI_Helper::get_settings();
            if (empty($_POST['api_key']) || $_POST['api_key'] === '••••••••') {
                $data['api_key'] = $cur['api_key'];
            }
        }
        \ApexOmega\Core\AI_Helper::save_settings($data);
        wp_send_json_success(['message'=>'ذخیره شد']);
    }

    private static function save_artist_weights(): void {
        $weights = $_POST['weights'] ?? [];
        if (is_string($weights)) $weights = json_decode(stripslashes($weights), true) ?: [];
        $clean = [];
        foreach ((array)$weights as $tid=>$w) {
            $clean[(int)$tid] = max(0,min(100,(int)$w));
        }
        \ApexOmega\Core\ArtistManager::save_weights($clean);
        wp_send_json_success(['message'=>'وزن‌ها ذخیره شد','count'=>count($clean)]);
    }

    private static function auto_artist_ai(): void {
        $res = \ApexOmega\Core\ArtistManager::auto_weight_via_ai();
        if (!empty($res['success'])) wp_send_json_success($res);
        wp_send_json_error($res, 400);
    }

    private static function auto_artist_ir(): void {
        $res = \ApexOmega\Core\ArtistManager::auto_weight_via_external();
        if (!empty($res['success'])) wp_send_json_success($res);
        wp_send_json_error($res, 400);
    }
    private static function test_ai(): void {
        $res = \ApexOmega\Core\AI_Helper::test_connection();
        if (!empty($res['success'])) wp_send_json_success($res); else wp_send_json_error($res, 400);
    }
    private static function save_artist_taxonomy(): void {
        $tax = sanitize_text_field($_POST['taxonomy'] ?? '');
        if ($tax === '__auto__') $tax = '';
        update_option(\ApexOmega\Core\ArtistManager::OPTION_TAXONOMY, $tax, false);
        // bust detect cache: just report
        wp_send_json_success(['message'=>'تاکسونومی ذخیره شد','taxonomy'=>$tax ?: 'خودکار']);
    }
    private static function undo_tier(): void {
        $exec = sanitize_text_field($_POST['execution_id'] ?? '');
        $res = \ApexOmega\Core\TierManager::undo_last_distribution($exec ?: null);
        if (!empty($res['success'])) wp_send_json_success($res); else wp_send_json_error($res, 400);
    }
    private static function export_artist_csv(): void {
        $csv = \ApexOmega\Core\Exporter::export_artist_csv();
        wp_send_json_success(['csv'=>$csv,'filename'=>'apex-artist-weights-'.gmdate('Y-m-d').'.csv']);
    }
    private static function export_history_csv(): void {
        $limit = isset($_POST['limit']) ? (int)$_POST['limit'] : 1000;
        $csv = \ApexOmega\Core\Exporter::export_history_csv(min(5000,max(10,$limit)));
        wp_send_json_success(['csv'=>$csv,'filename'=>'apex-history-'.gmdate('Y-m-d').'.csv']);
    }
    private static function export_tiers_json(): void {
        $json = \ApexOmega\Core\Exporter::export_tiers_json();
        wp_send_json_success(['json'=>$json,'filename'=>'apex-tiers-'.gmdate('Y-m-d').'.json']);
    }
    private static function import_artist_csv(): void {
        $csv = $_POST['csv'] ?? '';
        if (!$csv) wp_send_json_error(['message'=>'CSV خالی است'],400);
        $res = \ApexOmega\Core\Exporter::import_artist_csv(stripslashes($csv));
        if (!empty($res['success'])) wp_send_json_success($res); else wp_send_json_error($res,400);
    }
    private static function import_tiers_json(): void {
        $json = $_POST['json'] ?? '';
        if (!$json) wp_send_json_error(['message'=>'JSON خالی است'],400);
        $res = \ApexOmega\Core\Exporter::import_tiers_json(stripslashes($json));
        if (!empty($res['success'])) wp_send_json_success($res); else wp_send_json_error($res,400);
    }
    private static function save_evergreen(): void {
        $data = [
            'enabled' => !empty($_POST['enabled']),
            'rate_percent' => isset($_POST['rate_percent']) ? (float)$_POST['rate_percent'] : null,
            'max_views' => isset($_POST['max_views']) ? (int)$_POST['max_views'] : null,
        ];
        \ApexOmega\Core\Evergreen::save_settings($data);
        wp_send_json_success(['message'=>'تنظیمات Evergreen ذخیره شد','settings'=>\ApexOmega\Core\Evergreen::get_settings()]);
    }
    private static function save_rhythm(): void {
        $data = [
            'artist_ratio' => isset($_POST['artist_ratio']) ? (float)$_POST['artist_ratio'] : null,
            'title_ratio' => isset($_POST['title_ratio']) ? (float)$_POST['title_ratio'] : null,
            'unknown_threshold' => isset($_POST['unknown_threshold']) ? (int)$_POST['unknown_threshold'] : null,
            'unknown_cap' => isset($_POST['unknown_cap']) ? (int)$_POST['unknown_cap'] : null,
            'require_pair' => isset($_POST['require_pair']) ? !empty($_POST['require_pair']) : null,
        ];
        // filter nulls
        $data = array_filter($data, function($v){ return $v !== null; });
        \ApexOmega\Core\ArtistManager::save_rhythm_settings($data);
        wp_send_json_success(['message'=>'الگوی ریتم ذخیره شد','settings'=>\ApexOmega\Core\ArtistManager::get_rhythm_settings()]);
    }
    private static function save_autowatch(): void {
        $data = [
            'enabled' => isset($_POST['enabled']) ? !empty($_POST['enabled']) : null,
            'threshold' => isset($_POST['threshold']) ? (int)$_POST['threshold'] : null,
            'min_views' => isset($_POST['min_views']) ? (int)$_POST['min_views'] : null,
            'max_views' => isset($_POST['max_views']) ? (int)$_POST['max_views'] : null,
            'batch' => isset($_POST['batch']) ? (int)$_POST['batch'] : null,
            'only_recent_days' => isset($_POST['only_recent_days']) ? (int)$_POST['only_recent_days'] : null,
        ];
        $data = array_filter($data, function($v){ return $v !== null; });
        \ApexOmega\Core\AutoWatch::save_settings($data);
        wp_send_json_success(['message'=>'نگهبان ذخیره شد','settings'=>\ApexOmega\Core\AutoWatch::get_settings()]);
    }
}
